# HFIP v2.5 — Phased Build Plan

> **Purpose:** Break the full architecture into 5 manageable phases.  
> Each phase produces a working, testable system — never a half-built one.  
> Complete one phase fully before starting the next.

---

## How to Read This Plan

Each phase has:
- **Goal** — what you can do when this phase is done
- **Files to create** — exact paths, in order
- **Validation test** — how you know the phase is complete before moving on
- **Time estimate** — realistic, including debugging

---

## Phase 1 — Foundation: Data + LLM Infrastructure
**Duration: 3–4 days**  
**Goal: Fetch real data for any stock and call any LLM through a single interface**

By the end of Phase 1 you can run:
```bash
python src/main.py --ticker RELIANCE.NS --exchange IN
# Builds the KnowledgeGraph and executes a single local or fallback LLM call
```

Nothing does analysis yet. But the plumbing is solid and tested.

---

### Step 1.1 — Project skeleton and config (Day 1 morning)

The current repository already contains the key Phase 1 files:

```
config/settings.yaml
requirements.txt
src/main.py
src/utils/config_loader.py
src/data/knowledge_graph.py
src/data/intelligence_builder.py
src/data/stock_fetcher.py
src/data/news_fetcher.py
src/data/regime_fetcher.py
src/utils/cache.py
src/models/llm_factory.py
src/models/ollama_client.py
```

Verify these existing files and then run the validation commands below.

**`requirements.txt`**
```
yfinance>=0.2.40
httpx>=0.27.0
pyyaml>=6.0
python-dotenv>=1.0
rich>=13.0
aiohttp>=3.9
feedparser>=6.0
requests>=2.31
```

**`.env.example`**
```
OLLAMA_BASE_URL=http://localhost:11434
GEMINI_API_KEY=
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
NEWSAPI_KEY=
```

**Validation:** `pip install -r requirements.txt` completes without errors.

---

### Step 1.2 — KnowledgeGraph dataclass (Day 1 afternoon)

**File:** `src/data/knowledge_graph.py`

The repo already contains `src/data/knowledge_graph.py` with JSON serialization support.
Validate it by roundtripping a `KnowledgeGraph` instance through `to_json()` and `from_json()`.

**Validation:** 
```bash
python - <<'PY'
from src.data.knowledge_graph import KnowledgeGraph
kg = KnowledgeGraph(
    ticker='TEST', exchange='IN', company_name='Test Co', sector='Tech', industry='Software',
    balance_sheet={}, income_statement={}, cash_flow={}, key_ratios={}, valuation_metrics={},
    promoter_holding=[], fii_holding=[], dii_holding=[], insider_transactions=[], peers=[],
    market_position={}, governance_flags=[], debt_schedule={}, analyst_ratings={}, earnings_surprises=[],
    news_headlines=[], regime_data={}, fii_flow_30d=None, geopolitical_headlines=[], macro_indicators={},
    fetch_timestamp='2025-01-01T00:00:00', investment_duration_months=12, analysis_depth='balanced', data_gaps=[]
)
json_str = kg.to_json()
kg2 = KnowledgeGraph.from_json(json_str)
print(kg2.ticker)
PY
```

---

### Step 1.3 — Stock data fetcher (Day 2)

**File:** `src/data/stock_fetcher.py`

Fetches from Yahoo Finance using `yfinance`. Populates all KnowledgeGraph
financial fields. Build field by field, test each one:

```python
class StockFetcher:
    def fetch(self, ticker: str, exchange: str) -> dict:
        """
        Returns a dict matching KnowledgeGraph financial fields.
        exchange: "IN" appends .NS if not already present.
        """
        import yfinance as yf
        symbol = ticker if exchange == "US" else (
            ticker if ticker.endswith(".NS") else f"{ticker}.NS"
        )
        stock = yf.Ticker(symbol)

        return {
            "ticker": ticker,
            "exchange": exchange,
            "company_name": stock.info.get("longName", ticker),
            "sector": stock.info.get("sector", "Unknown"),
            "industry": stock.info.get("industry", "Unknown"),
            "balance_sheet": stock.balance_sheet.to_dict() if stock.balance_sheet is not None else {},
            "income_statement": stock.financials.to_dict() if stock.financials is not None else {},
            "cash_flow": stock.cashflow.to_dict() if stock.cashflow is not None else {},
            "key_ratios": self._extract_ratios(stock),
            "valuation_metrics": self._extract_valuation(stock),
            "promoter_holding": self._extract_holders(stock, "promoter"),
            "fii_holding": self._extract_holders(stock, "institutional"),
            "dii_holding": [],
            "insider_transactions": stock.insider_transactions.to_dict("records")
                                   if stock.insider_transactions is not None else [],
            "peers": self._fetch_peers(stock),
            "market_position": {},
            "governance_flags": [],
            "debt_schedule": {},
            "analyst_ratings": self._extract_analyst(stock),
            "earnings_surprises": self._extract_earnings_surprises(stock),
        }

    def _extract_ratios(self, stock) -> dict:
        info = stock.info
        return {
            "roe":                info.get("returnOnEquity"),
            "roa":                info.get("returnOnAssets"),
            "debt_equity":        info.get("debtToEquity"),
            "current_ratio":      info.get("currentRatio"),
            "interest_coverage":  info.get("ebitda", 0) / max(info.get("totalDebt", 1), 1),
            "fcf_margin":         info.get("freeCashflow", 0) / max(info.get("totalRevenue", 1), 1),
            "related_party_pct":  None,   # not available from yfinance
        }

    def _extract_valuation(self, stock) -> dict:
        info = stock.info
        return {
            "pe_ratio":       info.get("trailingPE"),
            "pb_ratio":       info.get("priceToBook"),
            "ev_ebitda":      info.get("enterpriseToEbitda"),
            "peg_ratio":      info.get("pegRatio"),
            "market_cap":     info.get("marketCap"),
            "current_price":  info.get("currentPrice"),
        }

    def _extract_analyst(self, stock) -> dict:
        rec = stock.recommendations
        if rec is None or rec.empty:
            return {}
        latest = rec.tail(10).to_dict("records")
        return {"recent_recommendations": latest,
                "price_target": stock.info.get("targetMeanPrice")}

    def _extract_earnings_surprises(self, stock) -> list:
        earnings = stock.earnings_history
        if earnings is None or earnings.empty:
            return []
        return earnings.tail(4).to_dict("records")

    def _extract_holders(self, stock, holder_type: str) -> list:
        if holder_type == "institutional":
            h = stock.institutional_holders
        else:
            h = stock.major_holders
        if h is None or h.empty:
            return []
        return h.to_dict("records")

    def _fetch_peers(self, stock) -> list:
        # yfinance doesn't give peers directly
        # Return empty list; can be enriched later with manual peer list or news
        return []
```

**Validation:**
```bash
python -c "
from src.data.stock_fetcher import StockFetcher
import json
data = StockFetcher().fetch('TCS', 'IN')
print(json.dumps(data['key_ratios'], indent=2))
"
# Should print real ratio data for TCS.NS
```

---

### Step 1.4 — News fetcher (Day 2 afternoon)

**File:** `src/data/news_fetcher.py`

```python
import feedparser, requests
from datetime import datetime, timedelta

class NewsFetcher:
    def fetch(self, company_name: str, ticker: str) -> dict:
        headlines = self._google_news_rss(company_name)
        return {
            "news_headlines": headlines,
        }

    def _google_news_rss(self, query: str) -> list:
        url = f"https://news.google.com/rss/search?q={query.replace(' ', '+')}&hl=en-IN&gl=IN&ceid=IN:en"
        feed = feedparser.parse(url)
        articles = []
        cutoff = datetime.now() - timedelta(days=30)
        for entry in feed.entries[:20]:
            articles.append({
                "title": entry.get("title", ""),
                "published": entry.get("published", ""),
                "source": entry.get("source", {}).get("title", ""),
                "link": entry.get("link", ""),
                "sentiment": None,  # enriched later if needed
            })
        return articles
```

**Validation:**
```bash
python -c "
from src.data.news_fetcher import NewsFetcher
data = NewsFetcher().fetch('Reliance Industries', 'RELIANCE.NS')
print(f'Fetched {len(data[\"news_headlines\"])} articles')
print(data['news_headlines'][0]['title'])
"
```

---

### Step 1.5 — Regime fetcher (Day 3 morning)

**File:** `src/data/regime_fetcher.py`

```python
import yfinance as yf
import feedparser

class RegimeFetcher:
    GEOPOLITICAL_KEYWORDS = [
        "war", "sanctions", "tariff", "OPEC", "trade war",
        "chip shortage", "Taiwan", "crude oil", "FII outflow",
        "RBI rate", "Fed rate", "inflation"
    ]

    def fetch(self) -> dict:
        return {
            "regime_data":             self._fetch_market_indicators(),
            "fii_flow_30d":            None,    # NSE API or manual
            "geopolitical_headlines":  self._fetch_geo_news(),
            "macro_indicators":        self._fetch_macro(),
        }

    def _fetch_market_indicators(self) -> dict:
        tickers = {
            "vix_us":      "^VIX",
            "vix_india":   "^NIFVIX",
            "crude_brent": "BZ=F",
            "dxy":         "DX-Y.NYB",
            "usdinr":      "USDINR=X",
            "nifty":       "^NSEI",
        }
        data = {}
        for key, symbol in tickers.items():
            try:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period="5d")
                if not hist.empty:
                    data[key] = {
                        "current": round(hist["Close"].iloc[-1], 2),
                        "5d_change_pct": round(
                            (hist["Close"].iloc[-1] / hist["Close"].iloc[0] - 1) * 100, 2
                        )
                    }
            except Exception:
                data[key] = None
        return data

    def _fetch_geo_news(self) -> list:
        query = "geopolitical+war+sanctions+trade+war+oil+supply"
        url = f"https://news.google.com/rss/search?q={query}&hl=en&gl=US&ceid=US:en"
        feed = feedparser.parse(url)
        articles = []
        for entry in feed.entries[:15]:
            title = entry.get("title", "")
            matched_keywords = [kw for kw in self.GEOPOLITICAL_KEYWORDS
                                if kw.lower() in title.lower()]
            if matched_keywords:
                articles.append({
                    "title": title,
                    "published": entry.get("published", ""),
                    "keywords_matched": matched_keywords,
                })
        return articles

    def _fetch_macro(self) -> dict:
        rbi_feed = feedparser.parse(
            "https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=rss"
        )
        rbi_headlines = [e.get("title", "") for e in rbi_feed.entries[:5]]
        return {"rbi_recent_releases": rbi_headlines}
```

**Validation:**
```bash
python -c "
from src.data.regime_fetcher import RegimeFetcher
import json
data = RegimeFetcher().fetch()
print('VIX US:', data['regime_data'].get('vix_us'))
print('Crude:', data['regime_data'].get('crude_brent'))
print('Geo headlines:', len(data['geopolitical_headlines']))
"
```

---

### Step 1.6 — Intelligence Builder (assembles KnowledgeGraph) (Day 3 afternoon)

**File:** `src/data/intelligence_builder.py`

```python
import json
from datetime import datetime
from src.data.knowledge_graph import KnowledgeGraph
from src.data.stock_fetcher import StockFetcher
from src.data.news_fetcher import NewsFetcher
from src.data.regime_fetcher import RegimeFetcher
from src.utils.cache import Cache

class IntelligenceBuilder:
    def __init__(self, config):
        self.config = config
        self.cache = Cache(config)

    def build(self, ticker: str, exchange: str,
              duration_months: int, depth: str) -> KnowledgeGraph:
        cache_key = f"kg_{ticker}_{exchange}"
        cached = self.cache.get(cache_key, ttl_hours=self.config.cache.knowledge_graph_ttl_hours)
        if cached:
            return KnowledgeGraph.from_json(cached)

        stock_data  = StockFetcher().fetch(ticker, exchange)
        news_data   = NewsFetcher().fetch(stock_data["company_name"], ticker)
        regime_data = RegimeFetcher().fetch()

        kg = KnowledgeGraph(
            fetch_timestamp=datetime.now().isoformat(),
            investment_duration_months=duration_months,
            analysis_depth=depth,
            data_gaps=[],
            **stock_data,
            **news_data,
            **regime_data,
        )
        self.cache.set(cache_key, kg.to_json())
        return kg
```

**File:** `src/utils/cache.py`

```python
import json, os, time

class Cache:
    def __init__(self, config):
        self.cache_dir = ".cache"
        os.makedirs(self.cache_dir, exist_ok=True)

    def get(self, key: str, ttl_hours: float) -> str | None:
        path = os.path.join(self.cache_dir, f"{key}.json")
        if not os.path.exists(path):
            return None
        age_hours = (time.time() - os.path.getmtime(path)) / 3600
        if age_hours > ttl_hours:
            return None
        with open(path) as f:
            return f.read()

    def set(self, key: str, value: str):
        path = os.path.join(self.cache_dir, f"{key}.json")
        with open(path, "w") as f:
            f.write(value)
```

---

### Step 1.7 — LLM factory + Ollama client (Day 4)

The repository already includes the implemented LLM factory and Ollama client.
Current files:
- `src/models/base_llm_client.py`
- `src/models/ollama_client.py`
- `src/models/gemini_client.py`
- `src/models/llm_factory.py`

The fallback sequence in `get_llm_with_fallback()` is:
- primary model
- `fallback`
- `fallback_2`
- `ollama.office_model`
- `fallback_3` / direct Gemini API when no local Ollama models exist

`config/settings.yaml` also includes `ollama.office_model` and per-agent `fallback_2` / `fallback_3`, so you can override the safe local fallback without code changes.

**Validation:**
```bash
python - <<'PY'
from src.models.llm_factory import get_llm_with_fallback
from src.utils.config_loader import load_config
cfg = load_config('config/settings.yaml')
llm = get_llm_with_fallback('fundamental', cfg)
print(type(llm).__name__)
print(llm.get_model_name())
PY
```

If your local Ollama server is running, this should resolve to an Ollama model. If Ollama is unavailable and `fallback_3` is configured, the code can fall back to the direct Gemini API.

---

### Phase 1 Completion Checklist

```
[ ] pip install -r requirements.txt works cleanly
[ ] StockFetcher().fetch('TCS', 'IN') returns real data
[ ] NewsFetcher().fetch('Tata', 'TCS.NS') returns headlines
[ ] RegimeFetcher().fetch() returns VIX, crude, and geo news
[ ] IntelligenceBuilder().build('RELIANCE.NS', 'IN', 18, 'balanced') 
    returns a full KnowledgeGraph object
[ ] KnowledgeGraph.to_json() → from_json() roundtrip works
[ ] Cache saves and loads correctly (run twice, second call is faster)
[ ] OllamaClient.complete() returns valid JSON from a test prompt
[ ] llm_factory fallback works (stop Ollama, verify it switches to Gemini API)
```

---

---

## Phase 2 — Specialist Agents + Deterministic Risk Engine
**Duration: 4–5 days**  
**Goal: Run all 6 analysis agents in parallel and get structured JSON reports**

By the end of Phase 2 you can run:
```bash
python src/main.py --ticker TCS.NS --exchange IN --duration 18
# Prints 6 JSON reports: fundamental, macro, moat, growth, risk_narrative, regime
# Each report has a score and structured evidence
```

Still no debate, no CIO. But you can already read meaningful analysis.

---

### Step 2.1 — Deterministic Risk Engine (Day 1 of Phase 2)

**File:** `src/data/risk_engine.py`

Copy the `DeterministicRiskEngine` class from architecture Section 6 exactly.
This is pure Python — no LLM, no network calls.

Then write a test:

```python
# tests/test_risk_engine.py
from src.data.risk_engine import DeterministicRiskEngine

def test_high_pledge_scores_high():
    # Build a minimal KG-like dict with high pledge
    mock_kg = MockKG(promoter_pledge=45, debt_equity=0.3, interest_coverage=8)
    engine = DeterministicRiskEngine()
    result = engine.compute(mock_kg)
    assert result["risk_level"] in ["HIGH", "CRITICAL"]
    assert result["det_risk_score"] >= 5.5

def test_clean_company_scores_low():
    mock_kg = MockKG(promoter_pledge=2, debt_equity=0.1, interest_coverage=15)
    engine = DeterministicRiskEngine()
    result = engine.compute(mock_kg)
    assert result["risk_level"] == "LOW"
    assert result["det_risk_score"] < 3.5
```

**Validation:** `python -m pytest tests/test_risk_engine.py -v` — all tests pass.

---

### Step 2.2 — Base agent class (Day 1 afternoon)

**File:** `src/agents/base_agent.py`

All agents inherit from this. Handles prompt loading, LLM call, JSON parsing,
error recovery, and logging.

```python
import json, logging
from pathlib import Path
from src.data.knowledge_graph import KnowledgeGraph
from src.models.base_llm_client import BaseLLMClient

logger = logging.getLogger(__name__)

class BaseAgent:
    AGENT_NAME: str = "base"
    PROMPT_FILE: str = ""
    REQUIRED_KG_FIELDS: list[str] = []

    def __init__(self, llm: BaseLLMClient, config):
        self.llm = llm
        self.config = config
        self.system_prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        path = Path("config/prompts") / self.PROMPT_FILE
        if not path.exists():
            raise FileNotFoundError(f"Prompt not found: {path}")
        return path.read_text()

    def _build_user_message(self, kg: KnowledgeGraph, extra: dict = None) -> str:
        data = kg.extract(self.REQUIRED_KG_FIELDS)
        if extra:
            data.update(extra)
        import json
        return f"Analyse the following data:\n\n{json.dumps(data, default=str, indent=2)}"

    async def analyze(self, kg: KnowledgeGraph, **kwargs) -> dict:
        try:
            agent_cfg = self.config.agents.get(self.AGENT_NAME, {})
            user_msg = self._build_user_message(kg, kwargs.get("extra"))
            raw = self.llm.complete(
                system_prompt=self.system_prompt,
                user_message=user_msg,
                temperature=agent_cfg.get("temperature", 0.2),
                max_tokens=agent_cfg.get("max_tokens", 2000),
                response_format="json"
            )
            return self._parse_and_validate(raw)
        except Exception as e:
            logger.error(f"[{self.AGENT_NAME}] failed: {e}")
            return {"agent": self.AGENT_NAME, "error": str(e), "score": None}

    def _parse_and_validate(self, raw: str) -> dict:
        try:
            # Strip markdown fences if model added them
            clean = raw.strip()
            if clean.startswith("```"):
                clean = "\n".join(clean.split("\n")[1:-1])
            result = json.loads(clean)
            if "agent" not in result:
                result["agent"] = self.AGENT_NAME
            return result
        except json.JSONDecodeError as e:
            logger.error(f"[{self.AGENT_NAME}] JSON parse failed: {e}\nRaw: {raw[:200]}")
            return {"agent": self.AGENT_NAME, "error": "json_parse_failed", "score": None}
```

---

### Step 2.3 — Five specialist agents (Days 2–3)

Create one file per agent. Each is tiny — just declares its name, prompt file,
required fields, and any agent-specific overrides. The base class does the rest.

**`src/agents/fundamental_agent.py`**
```python
from src.agents.base_agent import BaseAgent

class FundamentalAgent(BaseAgent):
    AGENT_NAME = "fundamental"
    PROMPT_FILE = "fundamental_agent.md"
    REQUIRED_KG_FIELDS = [
        "ticker", "company_name", "sector", "exchange",
        "investment_duration_months", "data_gaps",
        "balance_sheet", "income_statement", "cash_flow",
        "key_ratios", "valuation_metrics",
        "promoter_holding", "fii_holding", "dii_holding",
        "analyst_ratings", "earnings_surprises",
    ]
```

**`src/agents/macro_agent.py`**
```python
from src.agents.base_agent import BaseAgent

class MacroAgent(BaseAgent):
    AGENT_NAME = "macro"
    PROMPT_FILE = "macro_agent.md"
    REQUIRED_KG_FIELDS = [
        "ticker", "company_name", "sector", "exchange",
        "investment_duration_months",
        "news_headlines", "analyst_ratings", "earnings_surprises",
        "macro_indicators", "fii_holding", "fii_flow_30d",
    ]
```

**`src/agents/moat_agent.py`**
```python
from src.agents.base_agent import BaseAgent

class MoatAgent(BaseAgent):
    AGENT_NAME = "moat"
    PROMPT_FILE = "moat_agent.md"
    REQUIRED_KG_FIELDS = [
        "ticker", "company_name", "sector", "industry",
        "key_ratios", "valuation_metrics",
        "peers", "market_position",
    ]
```

**`src/agents/growth_valuation_agent.py`**
```python
from src.agents.base_agent import BaseAgent

class GrowthValuationAgent(BaseAgent):
    AGENT_NAME = "growth_valuation"
    PROMPT_FILE = "growth_valuation_agent.md"
    REQUIRED_KG_FIELDS = [
        "ticker", "company_name", "sector", "industry",
        "investment_duration_months",
        "income_statement", "cash_flow", "key_ratios",
        "valuation_metrics", "peers", "analyst_ratings",
    ]
```

**`src/agents/risk_narrative_agent.py`**
```python
from src.agents.base_agent import BaseAgent

class RiskNarrativeAgent(BaseAgent):
    AGENT_NAME = "risk_narrative"
    PROMPT_FILE = "risk_agent.md"
    REQUIRED_KG_FIELDS = [
        "ticker", "company_name", "sector",
        "key_ratios", "governance_flags",
        "promoter_holding", "debt_schedule",
    ]

    async def analyze(self, kg, det_risk_output: dict, **kwargs):
        # Inject the deterministic risk scores into the prompt context
        return await super().analyze(kg, extra={"det_risk_output": det_risk_output})
```

**`src/agents/market_regime_agent.py`**
```python
from src.agents.base_agent import BaseAgent

class MarketRegimeAgent(BaseAgent):
    AGENT_NAME = "market_regime"
    PROMPT_FILE = "market_regime_agent.md"
    REQUIRED_KG_FIELDS = [
        "ticker", "company_name", "sector",
        "regime_data", "fii_flow_30d",
        "geopolitical_headlines", "macro_indicators",
    ]
```

---

### Step 2.4 — Parallel orchestrator for Stage 2 (Day 4)

**File:** `src/pipeline/stage2_parallel.py`

```python
import asyncio
import logging
from src.data.knowledge_graph import KnowledgeGraph
from src.data.risk_engine import DeterministicRiskEngine
from src.agents.fundamental_agent import FundamentalAgent
from src.agents.macro_agent import MacroAgent
from src.agents.moat_agent import MoatAgent
from src.agents.growth_valuation_agent import GrowthValuationAgent
from src.agents.risk_narrative_agent import RiskNarrativeAgent
from src.agents.market_regime_agent import MarketRegimeAgent
from src.models.llm_factory import get_llm_with_fallback

logger = logging.getLogger(__name__)

async def run_specialist_agents(kg: KnowledgeGraph, config) -> dict:
    # Step 1: Deterministic Risk Engine (no LLM, runs first)
    det_risk = DeterministicRiskEngine().compute(kg)

    # Step 2: All LLM agents in parallel
    agents = {
        "fundamental":    FundamentalAgent(get_llm_with_fallback("fundamental", config), config),
        "macro":          MacroAgent(get_llm_with_fallback("macro", config), config),
        "moat":           MoatAgent(get_llm_with_fallback("moat", config), config),
        "growth":         GrowthValuationAgent(get_llm_with_fallback("growth_valuation", config), config),
        "market_regime":  MarketRegimeAgent(get_llm_with_fallback("market_regime", config), config),
    }

    # Risk narrative needs det_risk_output injected
    risk_llm = get_llm_with_fallback("risk_narrative", config)
    risk_agent = RiskNarrativeAgent(risk_llm, config)

    tasks = {
        name: agent.analyze(kg)
        for name, agent in agents.items()
    }
    tasks["risk_narrative"] = risk_agent.analyze(kg, det_risk_output=det_risk)

    results = await asyncio.gather(*tasks.values(), return_exceptions=True)
    agent_reports = dict(zip(tasks.keys(), results))

    # Handle partial failures
    for name, report in agent_reports.items():
        if isinstance(report, Exception):
            logger.error(f"Agent {name} raised exception: {report}")
            agent_reports[name] = {"agent": name, "error": str(report), "score": None}

    agent_reports["det_risk"] = det_risk
    return agent_reports
```

---

### Step 2.5 — Wire into main.py and test (Day 5)

```python
# src/main.py (Phase 2 version)
import asyncio, argparse, json
from src.utils.config_loader import load_config
from src.data.intelligence_builder import IntelligenceBuilder
from src.pipeline.stage2_parallel import run_specialist_agents
from rich.console import Console
from rich.json import JSON

console = Console()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ticker",   required=True)
    parser.add_argument("--exchange", default="IN")
    parser.add_argument("--duration", type=int, default=18)
    parser.add_argument("--depth",    default="balanced")
    args = parser.parse_args()

    config = load_config()
    kg = IntelligenceBuilder(config).build(
        args.ticker, args.exchange, args.duration, args.depth
    )
    console.print(f"\n[bold green]KnowledgeGraph built for {args.ticker}[/]")

    reports = asyncio.run(run_specialist_agents(kg, config))
    for name, report in reports.items():
        console.print(f"\n[bold cyan]── {name.upper()} ──[/]")
        console.print(JSON(json.dumps(report, default=str)))

if __name__ == "__main__":
    main()
```

**Phase 2 Completion Checklist:**
```
[ ] DeterministicRiskEngine returns consistent scores for the same input
[ ] pytest tests/test_risk_engine.py — all pass
[ ] All 6 agents return valid JSON with a "score" field (or "error" if failed)
[ ] Parallel run completes for TCS.NS in <3 minutes
[ ] Partial failure handled: kill one Ollama model, rest still complete
[ ] Cache works: second run of same ticker uses cached KG
[ ] main.py prints all 6 reports to terminal
```

---

---

## Phase 3 — Evidence Auditor + Bull/Bear Debate
**Duration: 4–5 days**  
**Goal: The 6 agent reports are audited, then Bull and Bear debate in 8 structured rounds**

By the end of Phase 3 you can run:
```bash
python src/main.py --ticker HDFC.NS --exchange IN --duration 24 --show-debate
# Prints the full 8-round debate transcript
# Each argument is traceable to a verified number in the KnowledgeGraph
```

---

### Step 3.1 — Evidence Auditor agent (Days 1–2)

**File:** `src/agents/evidence_auditor.py`

The Evidence Auditor is special — it receives all 6 reports plus the full
KnowledgeGraph, not just selected fields. Build it by extending BaseAgent
with a custom `_build_user_message`:

```python
import json
from src.agents.base_agent import BaseAgent
from src.data.knowledge_graph import KnowledgeGraph

class EvidenceAuditor(BaseAgent):
    AGENT_NAME = "evidence_auditor"
    PROMPT_FILE = "evidence_auditor.md"
    REQUIRED_KG_FIELDS = []  # receives full KG

    async def audit(self, kg: KnowledgeGraph, agent_reports: dict) -> dict:
        # Build a compact version of the KG (key numeric fields only)
        # to keep the prompt under token limits
        kg_numeric_summary = {
            "key_ratios":         kg.key_ratios,
            "valuation_metrics":  kg.valuation_metrics,
            "promoter_holding":   kg.promoter_holding[-2:] if kg.promoter_holding else [],
            "news_count":         len(kg.news_headlines),
            "data_gaps":          kg.data_gaps,
        }
        user_msg = json.dumps({
            "intelligence_bundle_summary": kg_numeric_summary,
            "agent_reports": {
                k: v for k, v in agent_reports.items()
                if k != "det_risk"  # det_risk is deterministic, skip
            }
        }, default=str, indent=2)

        return await super().analyze(kg, extra={"raw_user_msg": user_msg})

    def _build_user_message(self, kg, extra=None):
        # Override to use the pre-built message from audit()
        if extra and "raw_user_msg" in extra:
            return f"Audit the following agent reports against the IntelligenceBundle:\n\n{extra['raw_user_msg']}"
        return super()._build_user_message(kg, extra)
```

**Key thing to test:** Does the auditor correctly catch a planted numerical error?

```python
# tests/test_evidence_auditor.py
# Manually set a wrong ROE in the fundamental report
# Verify the auditor flags it in citation_errors
```

---

### Step 3.2 — Debate orchestrator (Days 3–4)

**File:** `src/pipeline/stage3_debate.py`

The debate is sequential (each round depends on the previous), so it cannot
be parallelised. Each round is one LLM call.

```python
import json
from src.models.llm_factory import get_llm_with_fallback
from src.agents.base_agent import BaseAgent

COMMITTEE_QUESTIONS = [
    "Which single assumption in your thesis has the highest uncertainty?",
    "What specific event or data point would cause you to completely reverse your position?",
    "Which risk is the market most underestimating right now for this stock?",
    "What catalyst could materially change the valuation within 6 months?",
    "Which financial metric deserves the greatest weight in the final rating, and why?"
]

class DebateOrchestrator:
    def __init__(self, config):
        self.config = config
        self.bull_llm = get_llm_with_fallback("bull_debate", config)
        self.bear_llm = get_llm_with_fallback("bear_debate", config)

    def run(self, audited_bundle: dict, ticker: str,
            company_name: str, duration: int) -> dict:
        context = {
            "ticker": ticker,
            "company_name": company_name,
            "duration": duration,
        }

        bull_reports = {
            "fundamental": audited_bundle["validated_reports"].get("fundamental"),
            "growth":      audited_bundle["validated_reports"].get("growth"),
            "moat":        audited_bundle["validated_reports"].get("moat"),
        }
        bear_reports = {
            "risk":         audited_bundle["validated_reports"].get("risk_narrative"),
            "macro":        audited_bundle["validated_reports"].get("macro"),
            "market_regime": audited_bundle["validated_reports"].get("market_regime"),
        }

        transcript = []

        # Round 0 — independent pre-debate opinions
        bull_r0 = self._call(self.bull_llm, "bull_round0", bull_reports, context)
        bear_r0 = self._call(self.bear_llm, "bear_round0", bear_reports, context)
        transcript.extend([{"round": 0, "role": "bull", "content": bull_r0},
                           {"round": 0, "role": "bear", "content": bear_r0}])

        # Round 1 — Bull opening thesis
        bull_r1 = self._call(self.bull_llm, "bull_round1", bull_reports, context)
        transcript.append({"round": 1, "role": "bull", "content": bull_r1})

        # Round 2 — Bear challenge (receives Bull's opening)
        bear_r2 = self._call(self.bear_llm, "bear_round2", bear_reports, context,
                             prior_round=bull_r1)
        transcript.append({"round": 2, "role": "bear", "content": bear_r2})

        # Round 3 — Bull rebuttal
        bull_r3 = self._call(self.bull_llm, "bull_round3", bull_reports, context,
                             prior_round=bear_r2)
        transcript.append({"round": 3, "role": "bull", "content": bull_r3})

        # Round 4 — Bear rebuttal
        bear_r4 = self._call(self.bear_llm, "bear_round4", bear_reports, context,
                             prior_round=bull_r3)
        transcript.append({"round": 4, "role": "bear", "content": bear_r4})

        # Round 5 — Committee Q&A (both sides answer all 5 questions)
        qa_prompt = "Answer each of these 5 Investment Committee questions:\n" + \
                    "\n".join(f"{i+1}. {q}" for i, q in enumerate(COMMITTEE_QUESTIONS))
        bull_qa = self._call(self.bull_llm, "committee_qa", bull_reports, context,
                             prior_round=qa_prompt)
        bear_qa = self._call(self.bear_llm, "committee_qa", bear_reports, context,
                             prior_round=qa_prompt)
        transcript.extend([{"round": 5, "role": "bull_qa", "content": bull_qa},
                           {"round": 5, "role": "bear_qa", "content": bear_qa}])

        # Round 6 — Bull closing
        bull_r6 = self._call(self.bull_llm, "bull_closing", bull_reports, context,
                             prior_round=json.dumps(transcript[-4:]))
        transcript.append({"round": 6, "role": "bull", "content": bull_r6})

        # Round 7 — Bear closing
        bear_r7 = self._call(self.bear_llm, "bear_closing", bear_reports, context,
                             prior_round=json.dumps(transcript[-4:]))
        transcript.append({"round": 7, "role": "bear", "content": bear_r7})

        # Extract final conviction scores
        bull_conviction = self._extract_score(bull_r6, "BULL CONVICTION SCORE")
        bear_conviction = self._extract_score(bear_r7, "BEAR CONVICTION SCORE")

        return {
            "transcript": transcript,
            "bull_conviction": bull_conviction,
            "bear_conviction": bear_conviction,
        }

    def _call(self, llm, round_id, reports, context, prior_round=None) -> str:
        user_msg = f"Context: {json.dumps(context)}\n\nReports: {json.dumps(reports, default=str)}"
        if prior_round:
            user_msg += f"\n\nPrevious round:\n{prior_round}"
        return llm.complete(
            system_prompt=self._load_round_instruction(round_id),
            user_message=user_msg,
            response_format="text",
            temperature=0.5,
        )

    def _load_round_instruction(self, round_id: str) -> str:
        # Round-specific instructions embedded as strings or loaded from prompts/
        instructions = {
            "bull_round0": "State your initial bull conviction score 0-10 and 2-sentence rationale before reading the bear's position.",
            "bear_round0": "State your initial bear conviction score 0-10 and 2-sentence rationale before reading the bull's position.",
            "bull_round1": "Present your bull opening thesis with 5 data-backed arguments.",
            "bear_round2": "Challenge the bull's opening. Cite specific numbers. Address at least 3 of their 5 arguments.",
            "bull_round3": "Rebuttal. Label each of your 5 original points: CONCEDE or DEFEND.",
            "bear_round4": "Your final position. Update conviction score (max ±1.5 from Round 0).",
            "committee_qa": "Answer the 5 Investment Committee questions with specific data.",
            "bull_closing": "Two-paragraph closing. Why did the bull case survive? What is the investor buying?",
            "bear_closing": "Two-paragraph closing. What is the bull case glossing over? At what price would you turn neutral?",
        }
        # Prepend the full agent persona from the main prompt files
        base = self._load_base_prompt("bull" if "bull" in round_id else "bear")
        return f"{base}\n\n--- CURRENT ROUND INSTRUCTION ---\n{instructions.get(round_id, '')}"

    def _load_base_prompt(self, side: str) -> str:
        from pathlib import Path
        path = Path(f"config/prompts/{side}_analyst.md")
        return path.read_text() if path.exists() else ""

    def _extract_score(self, text: str, label: str) -> float:
        import re
        pattern = rf"{label}:\s*(\d+(?:\.\d+)?)/10"
        match = re.search(pattern, text, re.IGNORECASE)
        return float(match.group(1)) if match else 5.0
```

**Phase 3 Completion Checklist:**
```
[ ] EvidenceAuditor.audit() returns valid JSON with reliability_score
[ ] Plant a wrong number in a report; auditor catches it in citation_errors
[ ] Debate runs all 8 rounds without crashing
[ ] Both conviction scores are extracted correctly from closing statements
[ ] --show-debate flag prints full transcript to terminal
[ ] HIGH_UNCERTAINTY flag triggers when conviction scores differ by >3
```

---

---

## Phase 4 — CIO Judgment + Final Report
**Duration: 3–4 days**  
**Goal: Full pipeline runs end-to-end and produces the complete investment memo**

By the end of Phase 4 you can run:
```bash
python src/main.py --ticker INFY.NS --exchange IN --duration 36
# Prints the complete HFIP v2.2 final report
# All 10 scores, formula shown step by step, 5-point summary, position size
```

---

### Step 4.1 — CIO agent (Days 1–2)

**File:** `src/agents/cio_agent.py`

The CIO receives everything — it has the largest user message of any agent.
Build a custom `_build_user_message` that assembles the full context:

```python
import json
from src.agents.base_agent import BaseAgent

class CIOAgent(BaseAgent):
    AGENT_NAME = "cio"
    PROMPT_FILE = "cio.md"

    async def judge(self, audited_bundle: dict, debate_result: dict,
                    det_risk: dict, config_weights: dict,
                    ticker: str, company_name: str,
                    duration_months: int) -> dict:
        user_msg = json.dumps({
            "ticker": ticker,
            "company_name": company_name,
            "investment_horizon_months": duration_months,
            "weights": config_weights,
            "agent_scores": {
                "fundamental":  audited_bundle["validated_reports"].get("fundamental", {}).get("score"),
                "macro":        audited_bundle["validated_reports"].get("macro", {}).get("score"),
                "moat":         audited_bundle["validated_reports"].get("moat", {}).get("moat_score"),
                "growth":       audited_bundle["validated_reports"].get("growth", {}).get("score"),
                "det_risk_score": det_risk.get("det_risk_score"),
            },
            "regime_multiplier": audited_bundle["validated_reports"].get(
                "market_regime", {}).get("sector_regime_multiplier", 0),
            "reliability_score":     audited_bundle.get("reliability_score"),
            "confidence_adjustment": audited_bundle.get("confidence_adjustment", 0),
            "bull_conviction": debate_result.get("bull_conviction"),
            "bear_conviction": debate_result.get("bear_conviction"),
            "debate_transcript_summary": debate_result.get("transcript", [])[-4:],
            "full_reports": audited_bundle.get("validated_reports", {}),
        }, default=str, indent=2)

        return await self._call_llm(user_msg)

    async def _call_llm(self, user_msg: str) -> dict:
        from src.data.knowledge_graph import KnowledgeGraph
        # Create a dummy KG just to satisfy base class signature
        raw = self.llm.complete(
            system_prompt=self.system_prompt,
            user_message=f"Make your CIO judgment based on:\n\n{user_msg}",
            temperature=0.1,
            max_tokens=3000,
            response_format="json"
        )
        return self._parse_and_validate(raw)
```

---

### Step 4.2 — Full pipeline orchestrator (Day 2–3)

**File:** `src/pipeline/orchestrator.py`

Connects all stages in sequence:

```python
import asyncio
from src.data.intelligence_builder import IntelligenceBuilder
from src.pipeline.stage2_parallel import run_specialist_agents
from src.agents.evidence_auditor import EvidenceAuditor
from src.agents.cio_agent import CIOAgent
from src.pipeline.stage3_debate import DebateOrchestrator
from src.models.llm_factory import get_llm_with_fallback

class PipelineOrchestrator:
    def __init__(self, config):
        self.config = config

    async def run(self, ticker: str, exchange: str,
                  duration_months: int, depth: str) -> dict:

        # Stage 1: Intelligence Builder
        kg = IntelligenceBuilder(self.config).build(
            ticker, exchange, duration_months, depth
        )

        # Stage 2: Parallel specialist agents
        agent_reports = await run_specialist_agents(kg, self.config)
        det_risk = agent_reports.pop("det_risk")

        # Stage 3: Evidence Auditor
        auditor = EvidenceAuditor(
            get_llm_with_fallback("evidence_auditor", self.config),
            self.config
        )
        audited_bundle = await auditor.audit(kg, agent_reports)

        # Stage 4: Bull vs Bear debate
        debate = DebateOrchestrator(self.config)
        debate_result = debate.run(
            audited_bundle, ticker, kg.company_name, duration_months
        )

        # Stage 5: CIO judgment
        weights = self.config.scoring_weights
        cio = CIOAgent(
            get_llm_with_fallback("cio", self.config),
            self.config
        )
        cio_output = await cio.judge(
            audited_bundle, debate_result, det_risk,
            weights, ticker, kg.company_name, duration_months
        )

        return {
            "kg_metadata":      {"ticker": kg.ticker, "company": kg.company_name,
                                 "fetched": kg.fetch_timestamp},
            "agent_reports":    agent_reports,
            "det_risk":         det_risk,
            "audited_bundle":   audited_bundle,
            "debate":           debate_result,
            "cio":              cio_output,
        }
```

---

### Step 4.3 — Report formatter and final main.py (Day 4)

**File:** `src/utils/report_formatter.py`

Renders the `cio_output` dict into the box-formatted final report shown in the
architecture document Section 14. Use Rich's `Panel`, `Table`, and box drawing.

```python
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

def print_final_report(cio: dict, debate: dict, audited: dict):
    title = f"HFIP v2.2 — {cio.get('ticker')} ({cio.get('company_name')})"

    scores = cio.get("scores", {})
    calc   = cio.get("score_calculation", {})

    # Main panel
    lines = [
        f"[bold yellow]FINAL RATING: {cio.get('final_rating')}/10  [{cio.get('verdict')} — {cio.get('conviction')} CONVICTION][/]",
        f"Investment Horizon: {cio.get('investment_horizon_months')} months  |  Uncertainty: {cio.get('uncertainty')}",
        f"Evidence Reliability: {audited.get('reliability_score')}/10",
        "",
        "[bold]MULTIDIMENSIONAL SCORES:[/]",
        f"  Business Quality:    {scores.get('business_quality')}/10",
        f"  Investment Quality:  {scores.get('investment_quality')}/10",
        f"  Valuation:           {scores.get('valuation_score')}/10",
        f"  Macro Risk:          {scores.get('macro_risk')}/10",
        f"  Execution Risk:      {scores.get('execution_risk')}/10",
        f"  Catalyst Score:      {scores.get('catalyst_score')}/10",
        "",
        "[bold]FORMULA:[/]",
        f"  Weighted Raw: {calc.get('weighted_raw')}  |  "
        f"Confidence: {calc.get('confidence_penalty')}  |  "
        f"Debate adj: {calc.get('debate_adjustment')}  |  "
        f"Regime: {calc.get('regime_multiplier')}  |  "
        f"Final: {calc.get('final')}",
        "",
        "[bold]5-POINT SUMMARY:[/]",
    ] + cio.get("five_point_summary", []) + [
        "",
        f"[bold]EXPECTED CAGR:[/] {cio.get('expected_cagr')}  |  "
        f"[bold]POSITION SIZE:[/] {cio.get('recommended_position_size')}",
        f"[bold]BUY BELOW:[/] {cio.get('buy_below_price')}  |  "
        f"[bold]NEXT CATALYST:[/] {cio.get('next_catalyst_to_watch')}",
        f"[bold]THESIS RISK:[/] {cio.get('thesis_invalidating_risk')}",
    ]

    console.print(Panel("\n".join(lines), title=title, border_style="gold1"))
```

**Phase 4 Completion Checklist:**
```
[ ] orchestrator.run() completes end-to-end for RELIANCE.NS
[ ] CIO JSON output has all required fields (final_rating, scores dict, expected_cagr, etc.)
[ ] Formula calculation matches manual calculation from agent scores
[ ] Report formatter prints correctly to terminal
[ ] Test with AAPL --exchange US (US stock path works)
[ ] --no-debate flag skips to CIO directly with averaged estimates
[ ] JSON export works: python src/main.py --ticker TCS.NS --format json > report.json
```

---

---

## Phase 5 — Hardening, Testing & Streamlit Dashboard
**Duration: 5–7 days**  
**Goal: Production-grade reliability + a web interface anyone can use**

By the end of Phase 5:
```bash
# CLI still works
python src/main.py --ticker HDFC.NS --exchange IN

# Web app runs
streamlit run app.py
# Browser opens, user enters ticker, clicks Analyse, sees full report with charts
```

---

### Step 5.1 — Regression test suite (Days 1–2)

Run the full pipeline on 10 known stocks. For each stock:
- Record the CIO output
- On the next run with the same cached KG, verify scores don't drift by >0.5 points
- This catches non-determinism in LLM responses (adjust temperature or add
  seed if a model supports it)

**Test stocks:**
```
India:  RELIANCE.NS, TCS.NS, HDFCBANK.NS, INFY.NS, WIPRO.NS
US:     AAPL, MSFT, GOOGL, TSLA, NVDA
```

**File:** `tests/test_regression.py`

```python
import json, asyncio, pytest
from src.pipeline.orchestrator import PipelineOrchestrator
from src.utils.config_loader import load_config

STOCKS = [("TCS.NS", "IN", 18), ("AAPL", "US", 12)]

@pytest.mark.parametrize("ticker,exchange,duration", STOCKS)
def test_pipeline_completes(ticker, exchange, duration):
    config = load_config()
    result = asyncio.run(
        PipelineOrchestrator(config).run(ticker, exchange, duration, "balanced")
    )
    cio = result["cio"]
    assert "final_rating" in cio
    assert 0 <= cio["final_rating"] <= 10
    assert cio["verdict"] in ["STRONG BUY","BUY","ACCUMULATE","HOLD","REDUCE","AVOID"]
    assert cio["expected_cagr"] is not None
```

---

### Step 5.2 — Edge cases and failure hardening (Day 2–3)

Test each of these deliberately:

```
[ ] Ticker not found on Yahoo Finance → graceful error message, not crash
[ ] Ollama server down → falls back to Gemini API
[ ] Gemini API key invalid → falls back to OpenAI
[ ] All LLMs fail → clean error with what data was fetched before failure
[ ] Agent returns malformed JSON → parsed as error, weight redistributed
[ ] News fetcher returns 0 articles → confidence flagged as low, continues
[ ] Very small company → sparse data, many data_gaps, report notes them all
[ ] Company with >40% promoter pledge → CRITICAL flag in report
[ ] Execution mode "quick" → skips moat and risk_narrative, completes faster
```

**File:** `tests/test_edge_cases.py`

---

### Step 5.3 — Streamlit web app (Days 3–5)

**File:** `app.py`

Four tabs, all built with standard Streamlit components:

**Tab 1 — Analysis Input**
```python
import streamlit as st
import asyncio, json
from src.pipeline.orchestrator import PipelineOrchestrator
from src.utils.config_loader import load_config

st.set_page_config(page_title="HFIP v2.2", layout="wide")
st.title("Hedge Fund Intelligence Platform")
st.caption("AI-powered multi-agent stock analysis")

with st.form("analysis_form"):
    col1, col2, col3 = st.columns(3)
    ticker   = col1.text_input("Ticker", placeholder="RELIANCE.NS or AAPL")
    exchange = col2.selectbox("Exchange", ["IN", "US"])
    duration = col3.selectbox("Horizon (months)", [6, 12, 18, 24, 36, 60], index=2)
    depth    = st.radio("Analysis Depth", ["quick", "balanced", "premium"],
                        index=1, horizontal=True)
    submitted = st.form_submit_button("Analyse", type="primary")
```

**Tab 2 — Final Report**

Render the CIO output as a clean card layout:
- Big rating number at the top
- 6-metric radar chart using `st.plotly_chart` (plotly is already common with streamlit)
- 5-point summary as bullet list
- Hold period, buy-below price, catalyst in a 3-column stat layout

**Tab 3 — Agent Scores**

Table showing all 6 agent scores, their weights, weighted contribution,
and which model was used. Colour-coded: green >7, amber 5–7, red <5.

**Tab 4 — Debate Transcript**

Expandable sections per round. Each round shows the role (Bull/Bear/Committee)
and the full text. Conviction score evolution shown as a small line chart
across rounds (Round 0 → Round 7).

---

### Step 5.4 — Model benchmarking mode (Day 6)

Add a `--benchmark` flag that runs the same ticker through two model configs
and outputs a side-by-side comparison:

```bash
python src/main.py --ticker TCS.NS --benchmark \
  --model-a settings_deepseek.yaml \
  --model-b settings_glm.yaml
# Prints two final ratings side by side + score breakdown diff
```

This lets you empirically test whether swapping a model actually changes results,
rather than just assuming it does.

---

### Step 5.5 — README and deployment (Day 7)

Update `README.md` with:
- Quickstart: clone → pip install → copy .env → pull Ollama models → run
- List of Ollama model pull commands:
  ```bash
  ollama pull deepseek-v4-pro
  ollama pull glm-5.2
  ollama pull kimi-k2.5
  ollama pull gemini-flash
  ollama pull minimax-m2.1
  ollama pull gpt-oss-120b
  ```
- Streamlit Cloud deployment instructions (set OLLAMA_BASE_URL to cloud Ollama)
- How to change any model: one line in settings.yaml

**Phase 5 Completion Checklist:**
```
[ ] All 10 regression stocks complete without crash
[ ] Same stock run twice gives scores within ±0.5 (determinism check)
[ ] All 8 edge cases handled gracefully
[ ] Streamlit app loads and runs an analysis without error
[ ] Radar chart renders for all 6 CIO scores
[ ] Debate transcript displays correctly in Tab 4
[ ] --benchmark mode outputs a diff correctly
[ ] README quickstart works on a fresh machine (test in a new virtualenv)
[ ] streamlit run app.py works on Streamlit Cloud with cloud Ollama URL
```

---

---

## Summary: What You Build in Each Phase

| Phase | Duration | What You Have at the End |
|-------|----------|--------------------------|
| **1 — Foundation** | 3–4 days | Real data from Yahoo Finance → KnowledgeGraph, any LLM callable via Ollama |
| **2 — Agents** | 4–5 days | 6 parallel agents produce structured reports with scores |
| **3 — Debate** | 4–5 days | Evidence Auditor validates reports; 8-round Bull/Bear debate runs |
| **4 — CIO + Report** | 3–4 days | Full pipeline end-to-end; professional investment memo printed to terminal |
| **5 — Hardening** | 5–7 days | 10-stock regression tests, edge cases handled, Streamlit web app live |
| **Total** | **~20–25 days** | Production-grade HFIP v2.2 |

## The Rule: Never Break the Working System

At the end of every phase, the system works. Each new phase adds to a working
foundation — it never temporarily breaks what already works. If Phase 3 breaks
something from Phase 2, fix it before declaring Phase 3 done.

---

*This plan is the companion to HFIP_v2_ARCHITECTURE.md. Architecture tells you what to build. This plan tells you in what order and how to know when each piece is done.*
