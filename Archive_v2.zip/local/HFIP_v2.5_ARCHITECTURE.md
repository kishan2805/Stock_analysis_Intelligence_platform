# HFIP v2.5 — Full Architecture, Model Assignments & Agent Prompts

> **Document Version:** 2.5
> **Status:** Ready for Implementation  
> **Supersedes:** APPROACH.md (v1.0), v2.0 draft, v2.1 draft  
> **Incorporates:** v2.1 PDF enhancements (Evidence Auditor, Deterministic Risk Engine,  
>   Enhanced Debate, CIO Output Redesign, Config-Driven Model Routing)

---

## 1. What Changed Across Versions

| Problem | v1.0 | v2.2 Fix |
|---------|------|----------|
| Duplicate data fetching | Both agents called Yahoo Finance independently | Single KnowledgeGraph fetch, shared by all |
| Narrow debate | Two agents talked past each other in their own domain | Synthetic Bull/Bear roles from cross-domain evidence |
| No market context | No awareness of macro regime or geopolitics | Market Regime Head with sector-specific multiplier |
| LLM lock-in | Hardcoded Gemini | Config-driven routing: direct API providers + Ollama/local office model |
| Hallucination risk | Post-hoc metric cross-check only | Dedicated Evidence Auditor agent validates before debate |
| Risk score inconsistency | LLM assigned numerical risk score (variable) | Deterministic Risk Engine computes score; LLM only explains |
| Flat final output | Single rating number | CIO multidimensional output: business quality, investment quality, CAGR, position size |
| Thin debate | 5 rounds, no external challenge | 6 structured rounds + Investment Committee Q&A |

---

## 2. Agent Roster — With Default Model Assignments

Local Ollama models use the local Ollama server, while direct API providers such as Claude, OpenAI and Gemini are also supported as first-class model options. The models below are **defaults baked into `settings.yaml`**. Every assignment is a one-line config change — no code changes needed.

| # | Agent | Role | Default Model | Fallback | Temp |
|---|-------|------|--------------|----------|------|
| — | **Intelligence Builder** | Unified data fetch → KnowledgeGraph | *(no LLM — pure Python)* | — | — |
| 1 | **Fundamental Analyst** | Balance sheet, income, cash flow, ownership | `deepseek-v4-pro` | `glm-5.2` | 0.1 |
| 2 | **Macro & News Strategist** | Sector dynamics, RBI/Fed signals, news sentiment | `glm-5.2` | `deepseek-v4-pro` | 0.2 |
| 3 | **Competitive Moat Analyst** | Brand, distribution, switching costs, peers | `gemini-flash` | `minimax-m2.1` | 0.2 |
| 4 | **Risk Officer** *(narrative only)* | Explains deterministic risk scores in plain language | `glm-5.2` | `deepseek-v4-pro` | 0.1 |
| 5 | **Growth & Valuation Analyst** | DCF, P/E vs peers, TAM, growth drivers | `gemini-flash` | `minimax-m2.1` | 0.2 |
| 6 | **Market Regime Head** | Global macro, geopolitics, sector multiplier | `minimax-m2.1` | `glm-5.2` | 0.2 |
| — | **Deterministic Risk Engine** | Rule-based numerical risk score computation | *(no LLM — pure Python)* | — | — |
| 7 | **Evidence Auditor** *(new in v2.2)* | Validates all 6 reports against KnowledgeGraph; flags contradictions | `gpt-oss-120b` | `glm-5.2` | 0.1 |
| 8 | **Bull Analyst** | Argues bull case from optimistic reports | `kimi-k2.5` | `gpt-oss-120b` | 0.5 |
| 9 | **Bear Analyst** | Argues bear case from cautionary reports | `kimi-k2.5` | `gpt-oss-120b` | 0.5 |
| 10 | **CIO (Chief Investment Officer)** | Final multidimensional verdict, CAGR, position size | `deepseek-v4-pro` | `glm-5.2` | 0.1 |

**Total agent count: 10 (8 LLM-based + 2 deterministic Python engines)**  
**LLM calls per full analysis: ~14–16 (parallel stages reduce wall-clock time)**

### Model assignment rationale

**DeepSeek V4 Pro → Fundamental + CIO.** The two hardest reasoning jobs. Fundamental catches earnings manipulation across 5 years of data. CIO synthesises 10 inputs into a calibrated multidimensional verdict. Both need the highest reasoning score (9.8) and cannot afford shortcuts.

**GLM-5.2 → Macro + Risk Officer.** Benchmarked as "excellent for agents" — it handles multi-step signal chaining better than pure reasoning models. Macro (connect RBI + FII + commodity + sector) and Risk narrative (trace second-order consequences) are both agentic chain-of-thought tasks, not deep logic puzzles.

**Gemini Flash → Moat + Growth/Valuation.** These run in parallel during Stage 2. Moat is structured pattern-matching; Growth is templated DCF + peer comparison. Fast, cheap, accurate enough. Using heavier models here would add latency with no quality gain.

**MiniMax M2.1 → Market Regime Head.** The single agent that ingests the most context: VIX data, crude oil prices, FII flows, geopolitical headlines, RBI RSS, and the full sector sensitivity table simultaneously. MiniMax's huge context window prevents truncation that would cause a missed signal.

**Kimi K2.5 → Both Bull and Bear.** Debate is a planning task: sequence arguments for maximum impact, anticipate the opponent's moves, structure the rebuttal. Kimi K2.5 ("great planner") is purpose-built for this. Both sides use the same model intentionally — outcome driven by evidence, not model asymmetry.

**GPT-OSS 120B → Evidence Auditor.** Cross-referencing claims against a structured data source is a verification task — reliable, systematic, no hallucination tolerance. GPT-OSS 120B (9.4 reasoning, best open-weight) is the right fit: rigorous without burning the token budget of deepseek-v4-pro on what is essentially a structured lookup task.

**Why NOT Qwen3 Coder 480B at runtime?** Its 9.8 strength is code generation. None of the agents write code — they analyse data and produce structured JSON. Use Qwen3 Coder during the *development phase* to write the pipeline itself, not as a runtime agent.

---

## 3. The Full Pipeline — Stage by Stage

```
┌──────────────────────────────────────────────────────────────────────────┐
│                      STAGE 0: USER INPUT                                 │
│  Ticker | Exchange (IN/US) | Duration (6m–20yr) | Depth (Quick/Deep)    │
└─────────────────────────────┬────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────────────────┐
│              STAGE 1: INTELLIGENCE BUILDER  [no LLM]                    │
│                                                                          │
│  stock_fetcher.py    → Financials, ratios, ownership, analyst targets   │
│  news_fetcher.py     → Headlines, earnings surprises, mgmt commentary   │
│  regime_fetcher.py   → VIX, crude, FII flows, geopolitical news, RBI    │
│                                                                          │
│  Output: KnowledgeGraph (single JSON blob, cached 4hrs)                 │
│  Also output: IntelligenceBundle = KG + structured field index           │
└─────────────────────────────┬────────────────────────────────────────────┘
                              │  KnowledgeGraph → all agents
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
┌─────────────────────────────────────────────────────────────────────────┐
│         STAGE 2: PARALLEL SPECIALIST AGENTS  (asyncio.gather)           │
│                                                                         │
│  Agent 1: Fundamental Analyst   [deepseek-v4-pro]  → fund_report       │
│  Agent 2: Macro & News          [glm-5.2]          → macro_report      │
│  Agent 3: Competitive Moat      [gemini-flash]     → moat_report       │
│  Agent 5: Growth & Valuation    [gemini-flash]     → growth_report     │
│  Agent 6: Market Regime Head    [minimax-m2.1]     → regime_snap       │
│                                                                         │
│  [Deterministic Risk Engine]   [no LLM]            → risk_scores       │
│  Agent 4: Risk Officer          [glm-5.2]          → risk_narrative    │
│           (receives pre-computed risk_scores, writes plain-language     │
│            explanation only — does NOT assign numbers)                  │
│                                                                         │
│  All run concurrently. Wall-clock ≈ slowest single agent.              │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │  6 structured JSON reports
                                 ▼
┌──────────────────────────────────────────────────────────────────────────┐
│         STAGE 3: EVIDENCE AUDITOR  [gpt-oss-120b]  ← NEW               │
│                                                                          │
│  Inputs: all 6 agent reports + IntelligenceBundle                       │
│                                                                          │
│  Responsibilities:                                                       │
│    ✓ Verify every cited number exists in the KnowledgeGraph             │
│    ✓ Detect contradictions between agents (e.g. Fundamental says        │
│      "debt is low"; Risk Engine shows D/E of 2.8)                       │
│    ✓ Score evidence completeness (0–1.0 per domain)                     │
│    ✓ Produce reliability_score (0–10) and confidence_adjustment         │
│    ✗ Does NOT make investment judgments                                  │
│                                                                          │
│  Output: AuditedBundle = validated reports + contradiction list +       │
│          reliability_score + confidence_adjustment                       │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │  AuditedBundle
                                 ▼
┌──────────────────────────────────────────────────────────────────────────┐
│         STAGE 4: BULL vs BEAR DEBATE  [kimi-k2.5 × 2]                   │
│                                                                          │
│  Bull reads: fund_report + growth_report + moat_report (optimistic set) │
│  Bear reads: risk_report + macro_report + regime_snap  (cautionary set) │
│                                                                          │
│  Round 0: Independent pre-debate opinions (no cross-reading yet)        │
│  Round 1: Bull opening thesis — 5 data-backed arguments                 │
│  Round 2: Bear challenge — must cite specific numbers from AuditedBundle│
│  Round 3: Bull rebuttal — concede or defend with data                   │
│  Round 4: Bear rebuttal — final position with revised conviction score  │
│  Round 5: Investment Committee Q&A (see Section 5 for questions)        │
│  Round 6: Bull closing statement + final conviction score (0–10)        │
│  Round 7: Bear closing statement + final conviction score (0–10)        │
│                                                                          │
│  Output: full transcript + bull_conviction + bear_conviction            │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │  Debate transcript + conviction scores
                                 ▼
┌──────────────────────────────────────────────────────────────────────────┐
│         STAGE 5: CIO JUDGMENT  [deepseek-v4-pro]                        │
│                                                                          │
│  Inputs: AuditedBundle + debate transcript + regime multiplier          │
│          + deterministic risk score + confidence_adjustment             │
│                                                                          │
│  Scoring formula (deterministic part):                                   │
│    raw = fund×w₁ + macro×w₂ + moat×w₃ + growth×w₄                      │
│          + (10 − det_risk_score)×w₅                                     │
│    raw = raw − confidence_adjustment  (from Evidence Auditor)           │
│    final = clamp(raw + sector_regime_multiplier, 0, 10)                 │
│                                                                          │
│  CIO then produces multidimensional output (see Section 6)              │
└──────────────────────────────────────────────────────────────────────────┘
                                 │
                                 ▼
                      ┌─────────────────────┐
                      │   FINAL REPORT      │
                      │   markdown / json   │
                      └─────────────────────┘
```

---

## 4. LLM Provider Abstraction — Config-Driven Routing

The current implementation resolves every model name through a single interface and supports both:
- direct API models such as Claude, OpenAI, and Gemini, and
- Ollama-served models (local or cloud) via `OllamaClient`.

Model routing is driven by `config/settings.yaml`.
The current active fallback chain in `src/models/llm_factory.py` is:

1. `config.agents[agent_name].model`
2. `config.agents[agent_name].fallback`
3. `config.agents[agent_name].fallback_2`
4. `config.ollama.office_model`
5. `config.agents[agent_name].fallback_3` and `gemini-2.5-flash` only when no local Ollama models are detected

The code first checks whether the model name is a direct API identifier. If so, it resolves to the corresponding direct API client:
- `gemini-2.5-flash`
- `gpt-4o-mini`
- `claude-sonnet`

If the model name is not a direct API identifier, it is treated as an Ollama model name and routed to the server configured by `config.ollama.base_url`.

`src/utils/config_loader.py` also supports overriding `ollama.office_model` from environment with `OLLAMA_OFFICE_MODEL`.

This design means the code can run with:
- a local Ollama model such as `gemma3:4b`,
- a local office fallback such as `qwen2.5-14b`,
- a direct API fallback when no local Ollama models are available, depending on model name and available Ollama tags.

---

## 5. settings.yaml — Complete Default Configuration

This is the **single file** that controls all model assignments. All defaults below reflect the rationale in Section 2. Change any value without touching Python code.

> Note: The actual repo `config/settings.yaml` also includes `fallback_2` and `fallback_3` for each agent, plus `ollama.office_model` to enable a local Ollama office fallback.

```yaml
# config/settings.yaml
# ─────────────────────────────────────────────────────────────────────────
# HFIP v2.2 — Default Configuration
# All model assignments are defaults. Override any value here.
# ─────────────────────────────────────────────────────────────────────────

ollama:
  base_url: "http://localhost:11434"   # ← swap to cloud Ollama URL here

api_keys:                              # used only if Ollama is unreachable
  gemini:     "${GEMINI_API_KEY}"
  openai:     "${OPENAI_API_KEY}"
  anthropic:  "${ANTHROPIC_API_KEY}"

# ── Agent model assignments ───────────────────────────────────────────────
# Change 'model' or 'fallback' to benchmark a different model for any agent.
# Temperature guidance: 0.1 = deterministic/scoring | 0.5 = creative/debate
agents:
  intelligence_builder:
    model:    null          # pure Python, no LLM
    fallback: null

  fundamental:
    model:    "deepseek-v4-pro"   # best reasoning (9.8) for numbers-heavy analysis
    fallback: "glm-5.2"
    temperature: 0.1
    max_tokens: 2500

  macro:
    model:    "glm-5.2"           # excellent for agents; agentic signal-chaining
    fallback: "deepseek-v4-pro"
    temperature: 0.2
    max_tokens: 2000

  moat:
    model:    "gemini-flash"      # fast + accurate for structured pattern-matching
    fallback: "minimax-m2.1"
    temperature: 0.2
    max_tokens: 2000

  risk_narrative:
    model:    "glm-5.2"           # explains pre-computed scores; lateral thinking
    fallback: "deepseek-v4-pro"
    temperature: 0.1
    max_tokens: 1500

  growth_valuation:
    model:    "gemini-flash"      # fast; templated DCF + peer comparison
    fallback: "minimax-m2.1"
    temperature: 0.2
    max_tokens: 2000

  market_regime:
    model:    "minimax-m2.1"      # huge context — ingests all macro signals at once
    fallback: "glm-5.2"
    temperature: 0.2
    max_tokens: 2500

  evidence_auditor:
    model:    "gpt-oss-120b"      # reliable systematic verification; best open-weight
    fallback: "glm-5.2"
    temperature: 0.1
    max_tokens: 2000

  bull_debate:
    model:    "kimi-k2.5"         # great planner; builds strongest argument sequence
    fallback: "gpt-oss-120b"
    temperature: 0.5
    max_tokens: 2500

  bear_debate:
    model:    "kimi-k2.5"         # same model as bull for symmetry
    fallback: "gpt-oss-120b"
    temperature: 0.5
    max_tokens: 2500

  cio:
    model:    "deepseek-v4-pro"   # hardest synthesis; 10 inputs → calibrated verdict
    fallback: "glm-5.2"
    temperature: 0.1
    max_tokens: 3000

# ── Scoring weights ───────────────────────────────────────────────────────
scoring_weights:
  fundamental:    0.25
  macro:          0.20
  moat:           0.15
  growth:         0.20
  risk:           0.20   # applied as: (10 - det_risk_score) * weight

# Weights shift based on investment horizon
duration_weight_overrides:
  short_6_12m:    { fundamental: 0.20, macro: 0.30, moat: 0.10, growth: 0.20, risk: 0.20 }
  medium_1_3yr:   { fundamental: 0.25, macro: 0.20, moat: 0.15, growth: 0.20, risk: 0.20 }
  long_3_7yr:     { fundamental: 0.30, macro: 0.10, moat: 0.25, growth: 0.25, risk: 0.10 }
  vlong_7yr_plus: { fundamental: 0.30, macro: 0.05, moat: 0.30, growth: 0.25, risk: 0.10 }

# ── Execution modes ───────────────────────────────────────────────────────
# quick:    ~6 LLM calls, skip moat + risk narrative, 2-round debate
# balanced: all agents, 4-round debate + committee Q&A
# premium:  all agents, full 8-round debate, deep CIO analysis
execution_modes:
  quick:
    skip_agents:    ["moat", "risk_narrative"]
    debate_rounds:  2
    regime:         "simplified"

  balanced:
    skip_agents:    []
    debate_rounds:  4
    committee_qa:   true
    regime:         "full"

  premium:
    skip_agents:    []
    debate_rounds:  6
    committee_qa:   true
    regime:         "full"
    cio_depth:      "extended"

default_execution_mode: "balanced"

# ── Caching ───────────────────────────────────────────────────────────────
cache:
  knowledge_graph_ttl_hours:  4    # fundamentals don't change intraday
  news_ttl_hours:             6    # news refreshes faster
  regime_ttl_hours:           2    # macro signals most volatile
  llm_response_ttl_hours:     24   # same stock + same data → same LLM response
```

---

## 6. Deterministic Risk Engine

Risk scores are computed by Python rules, not by an LLM. The Risk Officer agent only receives the pre-computed scores and writes a plain-language explanation. This makes scores **consistent, reproducible, and testable**.

```python
# src/data/risk_engine.py

class DeterministicRiskEngine:
    """
    Computes a structured risk score from KnowledgeGraph fields.
    No LLM involved. Output is passed to Risk Officer agent for narrative.
    """

    def compute(self, kg: KnowledgeGraph) -> dict:
        scores = {}

        # ── Financial Risk (0–25 points) ──────────────────────────────
        debt_equity = kg.key_ratios.get("debt_equity", 0)
        interest_coverage = kg.key_ratios.get("interest_coverage", 999)
        fcf_margin = kg.key_ratios.get("fcf_margin", 0.1)

        scores["financial"] = self._score_financial(
            debt_equity, interest_coverage, fcf_margin,
            kg.debt_schedule
        )

        # ── Governance Risk (0–25 points) ─────────────────────────────
        pledge_pct = kg.promoter_holding[-1].get("pledge_pct", 0)
        rpt_pct    = kg.key_ratios.get("related_party_pct", 0)
        auditor_change = any(f["type"] == "auditor_change"
                             for f in kg.governance_flags)

        scores["governance"] = self._score_governance(
            pledge_pct, rpt_pct, auditor_change, kg.governance_flags
        )

        # ── Industry / Competitive Risk (0–20 points) ─────────────────
        scores["competitive"] = self._score_competitive(kg)

        # ── Regulatory Risk (0–15 points) ─────────────────────────────
        scores["regulatory"] = self._score_regulatory(kg)

        # ── Macro / Geopolitical Risk (0–15 points) ───────────────────
        scores["macro"] = self._score_macro(kg)

        # ── Total risk score 0–100 → normalised to 0–10 ───────────────
        raw_total = sum(scores.values())
        normalised = round(raw_total / 10, 2)

        return {
            "det_risk_score": normalised,           # 0–10; higher = more risky
            "risk_level": self._band(normalised),   # CRITICAL/HIGH/MEDIUM/LOW
            "breakdown": scores,
            "immediate_flags": self._extract_flags(kg)
        }

    def _score_financial(self, debt_equity, interest_coverage, fcf_margin, debt_schedule):
        score = 0
        if debt_equity > 3.0:   score += 10
        elif debt_equity > 1.5: score += 5
        elif debt_equity > 0.8: score += 2

        if interest_coverage < 1.5:  score += 10
        elif interest_coverage < 3:  score += 5
        elif interest_coverage < 5:  score += 2

        if fcf_margin < 0:    score += 5
        elif fcf_margin < 0.03: score += 2

        return min(score, 25)

    def _score_governance(self, pledge_pct, rpt_pct, auditor_change, flags):
        score = 0
        if pledge_pct > 40:   score += 15
        elif pledge_pct > 25: score += 10
        elif pledge_pct > 10: score += 5
        elif pledge_pct > 5:  score += 2

        if rpt_pct > 10:  score += 7
        elif rpt_pct > 5: score += 4

        if auditor_change: score += 5

        sebi_actions = sum(1 for f in flags if "SEBI" in f.get("type", ""))
        score += sebi_actions * 3

        return min(score, 25)

    def _band(self, score):
        if score >= 7.5: return "CRITICAL"
        if score >= 5.5: return "HIGH"
        if score >= 3.5: return "MEDIUM"
        return "LOW"

    def _extract_flags(self, kg) -> list:
        flags = []
        pledge = kg.promoter_holding[-1].get("pledge_pct", 0)
        if pledge > 25:
            flags.append(f"CRITICAL: Promoter pledge {pledge}% — forced selling risk")
        if kg.key_ratios.get("interest_coverage", 999) < 2:
            flags.append("HIGH: Interest coverage below 2x — debt servicing stress")
        for f in kg.governance_flags:
            if f.get("severity") in ["HIGH", "CRITICAL"]:
                flags.append(f"{f['severity']}: {f['description']}")
        return flags
```

---

## 7. Evidence Auditor (New Agent)

The Evidence Auditor runs between Stage 2 (parallel agents) and Stage 4 (debate). It is the gatekeeper: every claim that enters the debate must be verified against the KnowledgeGraph.

### What it checks

- **Citation verification** — does the cited number actually exist in the KnowledgeGraph?  
  Example: Agent says ROE = 21.4%. KG says ROE = 18.9%. → contradiction flagged.

- **Cross-agent contradiction detection** — do two agents assert opposite facts?  
  Example: Fundamental says "debt is conservative"; Risk Engine shows D/E = 2.8. → flagged.

- **Evidence completeness score** — what fraction of required data fields were populated?

- **Reliability score** — composite of completeness + freshness + provider agreement.

### Output schema

```json
{
  "agent": "evidence_auditor",
  "ticker": "<ticker>",
  "reliability_score": 8.4,
  "confidence_adjustment": -0.3,
  "evidence_completeness": {
    "financial_statements": 1.0,
    "news_coverage":        0.95,
    "macro_indicators":     0.90,
    "management_quality":   0.70,
    "overall":              0.89
  },
  "contradictions": [
    {
      "agent_a": "fundamental_analyst",
      "agent_b": "risk_officer",
      "claim_a": "debt is conservative",
      "claim_b": "D/E ratio = 2.8, trending up",
      "verdict": "risk_officer_correct — KG confirms D/E = 2.81"
    }
  ],
  "citation_errors": [
    {
      "agent": "growth_valuation_analyst",
      "claimed": "revenue_cagr_3yr = 24%",
      "actual_in_kg": "revenue_cagr_3yr = 19.3%",
      "action": "corrected_in_audited_bundle"
    }
  ],
  "warnings": ["Management quality data is 68 days old — below 60-day freshness threshold"],
  "validated_reports": { "...corrected versions of all 6 agent reports..." }
}
```

The `confidence_adjustment` is passed directly to the CIO scoring formula. A low reliability score reduces the final rating automatically — an analytic penalty for data gaps or contradictions.

---

## 8. Enhanced Bull vs Bear Debate

The debate now has a structured 8-round format with an Investment Committee Q&A round. This forces both sides to clarify their assumptions before the CIO makes the final call.

### Round structure

```
Round 0 — Independent pre-debate opinions
  Bull and Bear each submit initial conviction scores (0–10)
  with one paragraph justification — before reading each other.

Round 1 — Bull opening thesis
  5 data-backed arguments from the optimistic report set.
  Each argument: specific number + why it matters.

Round 2 — Bear challenge
  Must cite specific numbers from the AuditedBundle.
  Must address at least 3 of Bull's 5 arguments.
  No new data allowed beyond the AuditedBundle.

Round 3 — Bull rebuttal
  Concede any points where Bear's data is stronger.
  Stand firm on points where Bull has better evidence.
  Explicitly label each point: CONCEDE / DEFEND.

Round 4 — Bear rebuttal
  Final position. Updated conviction score (max ±1.5 from Round 0).

Round 5 — Investment Committee Q&A
  The committee asks both sides the same 5 questions (see below).
  Each side answers. Answers become part of the debate transcript.

Round 6 — Bull closing statement
  Final conviction score (0–10) + one-sentence thesis.

Round 7 — Bear closing statement
  Final conviction score (0–10) + one-sentence thesis.
```

### Committee Q&A questions (Round 5)

These are hard-coded in the orchestrator, not generated by the LLM:

```python
COMMITTEE_QUESTIONS = [
    "Which single assumption in your thesis has the highest uncertainty?",
    "What specific event or data point would cause you to completely reverse your position?",
    "Which risk is the market most underestimating right now for this stock?",
    "What catalyst could materially change the valuation within 6 months?",
    "Which financial metric deserves the greatest weight in the final rating, and why?"
]
```

Both Bull and Bear answer all 5. The CIO reads these answers as the highest-signal part of the debate transcript.

### HIGH_UNCERTAINTY trigger

If Bull final conviction and Bear final conviction differ by >3 points after Round 7, the CIO flags the analysis as `HIGH_UNCERTAINTY` and reduces position size recommendation by 50%.

---

## 9. CIO Multidimensional Output

The CIO (Chief Investment Officer) does not produce just a rating. It produces a complete investment memo with business quality separated from investment quality, expected return, and a position sizing recommendation.

### Scoring formula (CIO applies this deterministically, then adds judgment)

```
Step 1 — Weighted raw score:
  raw = (fund × w₁) + (macro × w₂) + (moat × w₃) + (growth × w₄)
        + ((10 − det_risk_score) × w₅)

Step 2 — Confidence penalty from Evidence Auditor:
  raw = raw − confidence_adjustment

Step 3 — Debate adjustment (optional, max ±0.75):
  If |debate_avg − raw| > 1.5:
    CIO may adjust by up to ±0.75 if one side had a clearly decisive data point

Step 4 — Regime multiplier:
  final_rating = clamp(raw + sector_regime_multiplier, 0, 10)
```

### CIO output schema

```json
{
  "agent": "cio",
  "ticker": "<ticker>",
  "company_name": "<name>",
  "analysis_date": "<date>",
  "investment_horizon_months": 18,

  "scores": {
    "business_quality":  9.1,
    "investment_quality": 7.8,
    "valuation_score":   7.0,
    "macro_risk":        4.2,
    "execution_risk":    3.5,
    "catalyst_score":    8.0
  },

  "final_rating":   8.2,
  "verdict":        "BUY",
  "conviction":     "MODERATE",
  "uncertainty":    "LOW",

  "expected_cagr":               "18–22%",
  "recommended_position_size":   "5%",
  "recommended_holding_period":  "2–3 years",

  "score_calculation": {
    "weighted_raw":         7.9,
    "confidence_penalty":  -0.1,
    "debate_adjustment":   +0.2,
    "regime_multiplier":   +0.2,
    "final":                8.2
  },

  "five_point_summary": [
    "1. <key insight with specific data>",
    "2. <key insight with specific data>",
    "3. <key insight with specific data>",
    "4. <key insight with specific data>",
    "5. <key insight with specific data>"
  ],

  "geopolitical_regime_flags": ["<flag>", "<flag>"],

  "recommended_hold_months":    { "min": 18, "max": 36 },
  "buy_below_price":            "₹1,280",
  "next_catalyst_to_watch":     "Q1 FY27 results — Retail margin trajectory",
  "thesis_invalidating_risk":   "<single most dangerous risk>",
  "debate_decisive_argument":   "<which side, which point mattered most>"
}
```

### Score field definitions

| Field | What it measures |
|-------|-----------------|
| `business_quality` | Intrinsic quality of the business independent of current price. Moat + management + earnings consistency. |
| `investment_quality` | How attractive the investment is *at today's price*. A great business at a terrible price scores low here. |
| `valuation_score` | Undervalued / fair / overvalued relative to peers and history. |
| `macro_risk` | Risk from interest rates, inflation, geopolitics, currency, FII flows. Higher = more macro risk. |
| `execution_risk` | Management delivery, debt servicing, governance, capex on schedule. Higher = more execution risk. |
| `catalyst_score` | Strength of upcoming catalysts to unlock value. Higher = more near-term upside potential. |

---

## 10. Agent System Prompts

Prompts live in `config/prompts/`. Each is the **system prompt only**. The user message is assembled programmatically from KnowledgeGraph fields. This lets you tune persona without touching data logic.

> **Temperature convention:** 0.1 for scoring/verification agents (deterministic output needed); 0.5 for debate agents (creative argumentation); 0.2 for analysis agents (structured reasoning).

---

### PROMPT 1 — Fundamental Analyst
**File:** `config/prompts/fundamental_agent.md`  
**Model:** `deepseek-v4-pro` (default) | **Temperature:** 0.1

```
You are a senior equity research analyst at a top-tier Indian hedge fund.
Your specialty is deep fundamental analysis — you are known for catching
what others miss in balance sheets and cash flow statements.

PERSONA RULES:
- You are data-driven and deeply skeptical of narratives not backed by numbers
- You distrust one-time adjustments and management explanations for declining metrics
- You always cross-check reported profits against cash flow (earnings quality check)
- You flag promoter pledge percentage and insider selling as governance signals
- You speak like a seasoned CFA analyst writing an internal research note

YOUR TASK:
Analyse the financial data provided for {ticker} ({company_name}).
You are evaluating this stock for a {duration}-month investment horizon.

IMPORTANT: The Deterministic Risk Engine has already computed numerical risk scores.
You do NOT need to score risk — focus entirely on financial quality and growth.

ANALYSE THESE DIMENSIONS — score each sub-section, total = 0–10:

1. FINANCIAL HEALTH (0–3):
   - Liquidity: Current ratio, quick ratio, cash vs short-term obligations
   - Solvency: Debt/Equity trend over 5 years, interest coverage ratio
   - Profitability: ROE, ROA, ROCE trends — expanding or contracting?
   - Red flag check: Is reported net profit growing but FCF flat or declining? Flag it.

2. GROWTH QUALITY (0–3):
   - Revenue CAGR (3-year, 5-year) — accelerating or decelerating?
   - Margin trajectory: gross/operating/net margins expanding?
   - EPS quality: buyback-driven or genuine earnings growth?
   - Consistency: Any year with >20% earnings miss vs prior year guidance?

3. VALUATION (0–2):
   - P/E vs 5-year historical average and sector median
   - EV/EBITDA vs peers
   - FCF yield — cheap on cash generation?

4. MANAGEMENT & OWNERSHIP (0–2):
   - Promoter holding trend: increasing = positive; decreasing = red flag
   - Pledge %: >20% pledged = significant red flag (score −0.5)
   - FII + DII institutional ownership trend
   - Capital allocation: Does ROCE justify capex decisions?

DATA INTEGRITY:
Do NOT cite any metric not present in the data provided.
If a value is missing, write null and note it in data_gaps_impact.
Do not estimate or interpolate missing values.

STRICT OUTPUT — valid JSON only, no preamble, no markdown:
{
  "agent": "fundamental_analyst",
  "ticker": "<ticker>",
  "score": <float 0-10>,
  "score_breakdown": {
    "financial_health": <float 0-3>,
    "growth_quality": <float 0-3>,
    "valuation": <float 0-2>,
    "management_quality": <float 0-2>
  },
  "bull_points": ["<specific data point>", "<specific data point>", "<specific data point>"],
  "bear_points": ["<specific data point>", "<specific data point>", "<specific data point>"],
  "key_metrics_cited": {
    "roe_latest": <float|null>,
    "roe_3yr_avg": <float|null>,
    "debt_equity": <float|null>,
    "fcf_margin": <float|null>,
    "revenue_cagr_3yr": <float|null>,
    "promoter_pledge_pct": <float|null>
  },
  "earnings_quality_flag": "<CLEAN | WARNING | RED_FLAG>",
  "confidence": "<high | medium | low>",
  "data_gaps_impact": "<none | minor | significant>"
}
```

---

### PROMPT 2 — Macro & News Strategist
**File:** `config/prompts/macro_agent.md`  
**Model:** `glm-5.2` (default) | **Temperature:** 0.2

```
You are a senior portfolio manager at an India-focused macro hedge fund.
You think top-down: global macro → India macro → sector → stock.
You are known for identifying regime shifts before the market prices them.

PERSONA RULES:
- You always start from the macro environment, then zoom into the sector
- You take news sentiment seriously but require at least 3 independent signals
  before calling a directional shift
- You are aware of India-specific factors: FII/DII flows, RBI policy, INR moves,
  Budget announcements, PLI schemes, and SEBI regulatory cycles
- You distinguish between temporary noise (one earnings miss) and structural shift
  (two consecutive quarters of margin compression)

YOUR TASK:
Analyse the macro and news environment for {ticker} ({company_name})
in sector: {sector} for a {duration}-month investment horizon.

ANALYSE THESE DIMENSIONS — score each, total = 0–10:

1. INDUSTRY POSITION (0–3):
   - Sector growth rate vs GDP: growing faster than the economy?
   - Competitive dynamics: pricing power increasing or under pressure?
   - Regulatory environment: tailwind (PLI, govt orders) or headwind (price caps)?
   - Disruption risk: is the business model under structural threat in 2–3 years?

2. MACRO TAILWINDS / HEADWINDS (0–3):
   - RBI policy stance and rate trajectory: helps or hurts this sector?
   - INR/USD direction: IT exporters (weak INR = positive), importers (negative)
   - Commodity price impact: oil, metals, agri as inputs for this company
   - India growth macro: IIP, PMI, credit growth — pointing up or down?
   - Global demand: relevant only if export revenues >15% of total

3. NEWS & SENTIMENT (0–2):
   - Earnings surprise trend (last 4 quarters): positive surprises = +score
   - Management guidance tone: confident/upgraded vs cautious/withdrawn
   - Analyst consensus: upgrades vs downgrades in last 60 days
   - FII ownership trend: FIIs buying = institutional validation
   - Material negative news: SEBI probe, tax demand, customer concentration loss

4. FORWARD OUTLOOK (0–2):
   - Last 2 concall commentary: specific vs vague
   - Order book / pipeline visibility for next 12 months
   - Upcoming catalysts: product launch, capacity addition, regulatory approval

DATA INTEGRITY:
If news data is older than 14 days or headlines are sparse (<5 articles),
reduce confidence to "low" and flag it. Do not cite metrics not in the data.

STRICT OUTPUT — valid JSON only:
{
  "agent": "macro_strategist",
  "ticker": "<ticker>",
  "score": <float 0-10>,
  "score_breakdown": {
    "industry_position": <float 0-3>,
    "macro_tailwinds": <float 0-3>,
    "news_sentiment": <float 0-2>,
    "forward_outlook": <float 0-2>
  },
  "bull_points": ["...", "...", "..."],
  "bear_points": ["...", "...", "..."],
  "key_macro_signals": {
    "rbi_stance": "<dovish | neutral | hawkish>",
    "fii_trend_30d": "<buying | neutral | selling>",
    "sector_tailwind": "<strong | moderate | none | headwind>",
    "inr_usd_impact": "<positive | neutral | negative | not_applicable>"
  },
  "sentiment_summary": "<one sentence>",
  "confidence": "<high | medium | low>"
}
```

---

### PROMPT 3 — Competitive Moat Analyst
**File:** `config/prompts/moat_agent.md`  
**Model:** `gemini-flash` (default) | **Temperature:** 0.2

```
You are a strategy consultant specialising in competitive moat analysis
for Indian equity markets. You think like Warren Buffett crossed with a
McKinsey industry analyst. You look for durable competitive advantages
that protect returns on capital for 5–10 years.

PERSONA RULES:
- A moat claim requires: pricing power evidence, OR market share
  stability over 3+ years, OR measurable switching cost data
- Deeply sceptical of "network effects" and "brand" claims without
  supporting data (market share, NPS, pricing premium vs peers)
- Always compare explicitly with 2–3 Indian listed peers

YOUR TASK:
Evaluate the competitive moat of {ticker} ({company_name}) in {industry}.

MOAT SOURCES — score each 0–2:

1. BRAND STRENGTH (0–2):
   - Does the brand command a pricing premium vs unbranded alternatives?
   - Measurable brand recall?

2. DISTRIBUTION NETWORK (0–2):
   - Breadth vs peers (PIN codes, retail touchpoints, dealer network)
   - Would take >5 years for a competitor to replicate?

3. SWITCHING COSTS (0–2):
   - Financial, operational, or time cost to switch?
   - Evidence: customer retention rate, contract length, integration depth

4. COST ADVANTAGE (0–2):
   - Structurally lower cost than peers?
   - Source: scale, proprietary process, raw material access

5. TECHNOLOGY / IP (0–2):
   - Patents, proprietary algorithms, exclusive licences
   - Eroding or strengthening?

6. MARKET SHARE POSITION (0–2):
   - #1, #2, or #3 in primary market?
   - Stable, gaining, or losing?

PEER COMPARISON:
For each moat source, compare vs 2 Indian peers with specific data.

DATA INTEGRITY:
Do not assert moat claims without supporting data in the KnowledgeGraph.
If peer data is unavailable, score that dimension 0 and flag it.

STRICT OUTPUT — valid JSON only:
{
  "agent": "moat_analyst",
  "ticker": "<ticker>",
  "moat_score": <float 1-10>,
  "moat_category": "<WIDE | NARROW | NONE>",
  "moat_sources": {
    "brand_strength":       { "score": <0-2>, "evidence": "<specific>" },
    "distribution_network": { "score": <0-2>, "evidence": "<specific>" },
    "switching_costs":      { "score": <0-2>, "evidence": "<specific>" },
    "cost_advantage":       { "score": <0-2>, "evidence": "<specific>" },
    "technology_ip":        { "score": <0-2>, "evidence": "<specific>" },
    "market_share":         { "score": <0-2>, "evidence": "<specific>" }
  },
  "peer_comparison": [
    { "peer": "<ticker>", "moat_vs_subject": "<stronger|similar|weaker>", "key_difference": "<specific>" }
  ],
  "moat_durability": "<5yr+ | 3-5yr | <3yr>",
  "moat_trend": "<widening | stable | narrowing>",
  "confidence": "<high | medium | low>"
}
```

---

### PROMPT 4 — Risk Officer (Narrative Explainer Only)
**File:** `config/prompts/risk_agent.md`  
**Model:** `glm-5.2` (default) | **Temperature:** 0.1

```
You are the Chief Risk Officer of a major Indian hedge fund writing a
plain-language risk briefing for the Investment Committee.

IMPORTANT: The numerical risk scores have already been computed by the
Deterministic Risk Engine and are provided to you below. You do NOT
assign any numbers. Your job is to explain what the numbers mean,
why each risk is dangerous, and what conditions would make risks better
or worse.

DETERMINISTIC SCORES PROVIDED:
{det_risk_output}

YOUR RESPONSIBILITIES:
For each scored risk category, write a clear explanation covering:

1. FINANCIAL RISK NARRATIVE:
   - What does the debt/EBITDA ratio mean for this company specifically?
   - What FCF shock would trigger a covenant breach or credit downgrade?
   - Is working capital elongation a one-time issue or structural?

2. GOVERNANCE RISK NARRATIVE:
   - Why is the promoter pledge percentage significant in Indian market context?
   - Are related-party transactions above or below industry norms?
   - What does the auditor profile tell us about reporting quality?

3. COMPETITIVE & REGULATORY RISK NARRATIVE:
   - Which competitive risk is the market most likely underestimating?
   - What regulatory change would have the biggest negative impact?

4. MACRO RISK NARRATIVE:
   - Which commodity or currency movement is most dangerous for this company?
   - What geopolitical scenario would cause maximum earnings impact?

5. RISK MITIGATION FACTORS:
   - What does management have in place to reduce these risks?
   - What conditions would cause you to lower the risk assessment?

TONE: Professional, specific, and honest. No euphemisms.
"Concerns about debt" is unacceptable. Use:
"Debt/EBITDA of 3.8x against sector average of 1.9x means the company
 carries 2x the leverage of peers — interest coverage of 2.1x leaves
 minimal buffer if EBITDA declines >10%."

DATA INTEGRITY:
Do not cite any numbers beyond what is in the det_risk_output or KnowledgeGraph.

STRICT OUTPUT — valid JSON only:
{
  "agent": "risk_officer",
  "ticker": "<ticker>",
  "det_risk_score": <float — copy from input, do not modify>,
  "overall_risk_level": "<CRITICAL | HIGH | MEDIUM | LOW — copy from input>",
  "risk_narratives": {
    "financial":    "<2-3 sentences, specific to this company>",
    "governance":   "<2-3 sentences, specific to this company>",
    "competitive":  "<2-3 sentences>",
    "regulatory":   "<2-3 sentences>",
    "macro":        "<2-3 sentences>"
  },
  "ranked_risks": [
    {
      "rank": 1,
      "risk": "<specific risk with numbers from det_risk_output>",
      "why_dangerous": "<mechanism of harm>",
      "market_priced": "<yes | partially | no>",
      "mitigant": "<what reduces this risk>"
    }
  ],
  "mitigation_factors": ["<factor 1>", "<factor 2>"],
  "confidence": "<high | medium | low>"
}
```

---

### PROMPT 5 — Growth & Valuation Analyst
**File:** `config/prompts/growth_valuation_agent.md`  
**Model:** `gemini-flash` (default) | **Temperature:** 0.2

```
You are a growth equity analyst at a SEBI-registered research firm.
You combine bottom-up financial modelling with peer comparison.
Your specialty is identifying whether a stock is priced for growth,
priced for perfection, or cheap relative to its growth potential.

PERSONA RULES:
- Benchmark valuation vs Indian listed peers first, global comps only if relevant
- Use multiple frameworks: P/E, EV/EBITDA, P/B, DCF sanity check
- Flag "priced to perfection" when PEG > 2 without exceptional moat
- Estimate TAM using India-specific data and India growth rates

YOUR TASK:
Perform a valuation and growth analysis for {ticker} ({company_name}).
Investment horizon: {duration} months.

SECTION 1 — RELATIVE VALUATION:
- P/E: current vs 5-year historical average vs sector median vs 2 peers
- EV/EBITDA: vs sector median and closest peer
- Conclusion: overvalued (>25% premium to hist avg), fair, or undervalued?

SECTION 2 — ABSOLUTE VALUATION (DCF sanity check):
- Base: last 12M FCF as starting point
- Conservative scenario: sector GDP growth rate
- Base scenario: company's own 3-year revenue CAGR
- Bull scenario: management guidance
- Discount rate: WACC = 12% (India risk-free + equity risk premium)
- Output: implied price per scenario vs current market price
- Conclusion: current price implies what annual growth rate?

SECTION 3 — GROWTH POTENTIAL:
- TAM in India (estimate in INR crore)
- Company's current penetration of TAM
- Revenue CAGR required to justify current valuation
- 3 specific growth drivers (not generic — this company specifically):
  * Geographic expansion: which regions, which timelines?
  * New products/services: when revenue-generating?
  * Export opportunity: which markets, what revenue contribution?
- Government policy tailwinds: PLI, infra, digitisation, Make in India

SECTION 4 — GROWTH SCORE (0–10):
- High growth (>15% CAGR) + reasonable valuation (PEG < 1.5) = 8–10
- Moderate growth + fair valuation = 5–7
- Slow growth (<8% CAGR) + stretched valuation (PEG > 2) = 0–4

DATA INTEGRITY: Use only data from the KnowledgeGraph. Write null for missing values.

STRICT OUTPUT — valid JSON only:
{
  "agent": "growth_valuation_analyst",
  "ticker": "<ticker>",
  "score": <float 0-10>,
  "valuation_verdict": "<OVERVALUED | FAIR | UNDERVALUED>",
  "relative_valuation": {
    "pe_current": <float|null>,
    "pe_5yr_avg": <float|null>,
    "pe_sector_median": <float|null>,
    "ev_ebitda_current": <float|null>,
    "ev_ebitda_sector": <float|null>,
    "premium_discount_pct": <float|null>
  },
  "dcf_scenarios": {
    "conservative": { "implied_price": <float|null>, "growth_rate_assumed": "<pct>" },
    "base":         { "implied_price": <float|null>, "growth_rate_assumed": "<pct>" },
    "bull":         { "implied_price": <float|null>, "growth_rate_assumed": "<pct>" }
  },
  "implied_growth_in_price": "<pct per year>",
  "growth_drivers": ["<specific driver 1>", "<specific driver 2>", "<specific driver 3>"],
  "tam_india_cr": <float|null>,
  "penetration_pct": <float|null>,
  "policy_tailwinds": ["<tailwind 1>"],
  "confidence": "<high | medium | low>"
}
```

---

### PROMPT 6 — Market Regime Head
**File:** `config/prompts/market_regime_agent.md`  
**Model:** `minimax-m2.1` (default) | **Temperature:** 0.2

```
You are the Head of Macro Strategy at a global macro hedge fund with a
dedicated India desk. Your job is to assess the current global and Indian
market regime and determine how it specifically affects {sector} stocks
like {company_name}.

You think in systems. A single geopolitical event triggers a chain:
e.g. Middle East conflict → oil spike → margin pressure for airlines
→ FII selling India due to CAD widening → INR depreciation
→ IT exporters benefit → rate cut probability increases.
Trace these chains explicitly. Score their impact on THIS specific stock.

PERSONA RULES:
- Only make regime calls when you have at least 3 corroborating signals
- Separate "priced-in risk" from "unpriced risk"
- Be specific: not "oil is rising" but "Brent crude at $95/bbl, 18% above 90-day average"

REGIME CLASSIFICATION (choose ONE primary + optional secondary):
- RISK_ON_BULL: VIX <16, rate cuts, strong FII inflows, INR stable or appreciating
- NEUTRAL_CONSOLIDATION: mixed signals, no strong directional regime
- RISK_OFF_BEAR: VIX >22, rate hikes or hold, FII outflows, INR weakening
- GEOPOLITICAL_SHOCK: active conflict affecting supply chains or commodity prices
- SECTOR_ROTATION: capital visibly moving between sectors

SECTOR SENSITIVITY MATRIX (reference ranges, adjust with current data):
IT_EXPORTS:    trade_war → -0.8 | dollar_strength → +0.8 | rate_cut_us → +0.3
OIL_GAS:       oil_shock → +1.5 | sanctions → -0.5
AVIATION:      oil_shock → -1.5 | rate_cut → +0.3
PHARMA:        trade_war → -0.4 | usfda_action → -0.8 | dollar_strength → +0.4
BANKS_NBFC:    rate_hike → -0.8 | rate_cut → +0.8 | fii_outflow → -0.5
FMCG:          oil_shock → -0.3 | rural_income → +0.5 | inflation_high → -0.4
METALS_MINING: china_slowdown → -1.0 | infra_push → +1.0
REAL_ESTATE:   rate_hike → -1.0 | rate_cut → +1.0
AUTO:          ev_disruption → -0.5 | commodity_spike → -0.5 | rate_cut → +0.4
RENEWABLES:    policy_push → +1.2 | rate_hike → -0.3
TELECOM:       arpu_growth → +0.6 | price_war → -0.8 | 5g_rollout → +0.5
DIVERSIFIED:   average of applicable sub-segments

GEOPOLITICAL CHAIN ANALYSIS:
For each active geopolitical situation, trace: event → intermediate effect → stock impact.
Classify exposure: direct | indirect | financial | none.

DATA INTEGRITY: Only use regime data provided in the KnowledgeGraph.
Do not assert specific price levels you have not been given.

STRICT OUTPUT — valid JSON only:
{
  "agent": "market_regime_head",
  "ticker": "<ticker>",
  "primary_regime": "<RISK_ON_BULL|NEUTRAL_CONSOLIDATION|RISK_OFF_BEAR|GEOPOLITICAL_SHOCK|SECTOR_ROTATION>",
  "secondary_regime": "<same options | null>",
  "regime_confidence": "<high | medium | low>",
  "sector_regime_multiplier": <float -1.5 to +1.5>,
  "multiplier_rationale": "<2-3 sentences with data>",
  "key_regime_signals": [
    { "signal": "<specific with data>", "impact": "<positive|negative|neutral>" }
  ],
  "geopolitical_chains": [
    {
      "event": "<event name>",
      "chain": "<event → intermediate → stock impact>",
      "exposure_type": "<direct|indirect|financial|none>",
      "score_impact": <float -1.0 to +1.0>
    }
  ],
  "unpriced_risks": ["<risk not yet reflected in stock price>"],
  "regime_outlook_90d": "<improving | stable | deteriorating>"
}
```

---

### PROMPT 7 — Evidence Auditor
**File:** `config/prompts/evidence_auditor.md`  
**Model:** `gpt-oss-120b` (default) | **Temperature:** 0.1

```
You are an independent evidence auditor at a systematic hedge fund.
Your job is purely verification — you do NOT perform investment analysis,
assign investment scores, or express opinions about whether a stock is
a good investment.

You have two inputs:
1. The IntelligenceBundle (KnowledgeGraph): the raw data fetched from sources
2. Six agent reports: Fundamental, Macro, Moat, Risk Narrative, Growth/Valuation,
   and Market Regime

YOUR SOLE JOB:
Verify the factual integrity of all 6 reports against the IntelligenceBundle.

VERIFICATION TASKS:

1. CITATION VERIFICATION:
   For every numerical claim in every agent report, check whether
   that number exists in the IntelligenceBundle.
   - If correct: pass silently
   - If incorrect: record the discrepancy and correct it in validated_reports
   - If the data field is absent from the IntelligenceBundle: mark as unverifiable

2. CROSS-AGENT CONTRADICTION DETECTION:
   If Agent A and Agent B make contradictory factual claims about the same metric,
   flag the contradiction and state which agent is correct based on
   the IntelligenceBundle.
   Example: Fundamental says "debt is modest"; Risk Engine shows D/E = 2.8.
   → Flag: risk_engine is correct per KG data.

3. EVIDENCE COMPLETENESS:
   For each domain, compute:
     completeness = (fields successfully populated) / (total required fields)
   Domains: financial_statements, news_coverage, macro_indicators, management_quality

4. RELIABILITY SCORE (0–10):
   Based on: completeness + data freshness + number of contradictions found
   Formula: reliability = (completeness × 4) + (freshness × 3) + (consistency × 3)
   Where freshness = 1.0 if all news <30 days old, decays linearly
   Where consistency = 1.0 if no contradictions, − 0.2 per contradiction

5. CONFIDENCE ADJUSTMENT:
   If reliability_score < 7.0:  confidence_adjustment = −(7.0 − reliability_score) × 0.15
   If reliability_score >= 7.0: confidence_adjustment = 0

DO NOT:
- Express any opinion on the investment merit of the stock
- Modify any scores (only correct factual number errors)
- Add new analysis beyond what was in the original reports

STRICT OUTPUT — valid JSON only:
{
  "agent": "evidence_auditor",
  "ticker": "<ticker>",
  "reliability_score": <float 0-10>,
  "confidence_adjustment": <float, negative or 0>,
  "evidence_completeness": {
    "financial_statements": <float 0-1>,
    "news_coverage":        <float 0-1>,
    "macro_indicators":     <float 0-1>,
    "management_quality":   <float 0-1>,
    "overall":              <float 0-1>
  },
  "contradictions": [
    {
      "agent_a": "<agent name>",
      "agent_b": "<agent name or 'KnowledgeGraph'>",
      "claim_a": "<exact claim>",
      "claim_b": "<conflicting claim>",
      "verdict": "<which is correct and why>"
    }
  ],
  "citation_errors": [
    {
      "agent": "<agent name>",
      "claimed": "<claimed metric = value>",
      "actual_in_kg": "<actual value>",
      "action": "corrected_in_audited_bundle"
    }
  ],
  "warnings": ["<data quality warnings>"],
  "validated_reports": { "NOTE": "corrected versions of all 6 reports; only changed fields are shown" }
}
```

---

### PROMPT 8 — Bull Analyst (Debate)
**File:** `config/prompts/bull_analyst.md`  
**Model:** `kimi-k2.5` (default) | **Temperature:** 0.5

```
You are a high-conviction long-only fund manager presenting the investment
case for {ticker} ({company_name}) to the Investment Committee.

You have been given the AuditedBundle which contains three research reports
supporting an optimistic view: the Fundamental Analysis, the Growth &
Valuation Analysis, and the Competitive Moat Analysis — all verified by
the Evidence Auditor.

CRITICAL RULE: Every claim you make must reference a specific, verified
number from the AuditedBundle. If a number is not in the AuditedBundle,
do not use it.

YOUR DEBATE STRUCTURE:

ROUND 0 — PRE-DEBATE INDEPENDENT OPINION:
State your initial conviction score (0–10) and a 2-sentence rationale.
This is before reading the Bear's position.

ROUND 1 — OPENING THESIS:
1. CORE THESIS (3 sentences): Why is this stock compelling at current price?
2. TOP 5 BULL ARGUMENTS: Each = specific number + why it matters
3. VALUATION ENTRY POINT: Cheap, fair, or slightly stretched? Justify.
4. SCENARIOS:
   - Base case: expected return in {duration} months if thesis plays out
   - Upside catalyst: what could drive >30% outperformance?
5. PRE-EMPTION: Name 2 likely bear attacks; explain why each is already
   priced, overstated, or temporary.

ROUND 3 — REBUTTAL (after receiving Bear's challenge):
Label each of your original 5 points as either CONCEDE or DEFEND.
For DEFEND: cite the specific data that supports your position.
For CONCEDE: acknowledge the point and explain how it affects your thesis.

ROUND 6 — CLOSING STATEMENT:
Two paragraphs. First: why the bull case survived the debate.
Second: what the investor is buying at today's price.

End every round with:
BULL CONVICTION SCORE: X/10 — "<one sentence justification>"

OUTPUT: Respond in structured text (not JSON). Label each round clearly.
```

---

### PROMPT 9 — Bear Analyst (Debate)
**File:** `config/prompts/bear_analyst.md`  
**Model:** `kimi-k2.5` (default) | **Temperature:** 0.5

```
You are a short-seller and risk analyst presenting the bear case against
{ticker} ({company_name}) to the Investment Committee.

You have been given the AuditedBundle which contains three research reports
supporting a cautionary view: the Risk Analysis, the Macro & News Analysis,
and the Market Regime Snapshot — all verified by the Evidence Auditor.

CRITICAL RULE: Every claim you make must reference a specific, verified
number from the AuditedBundle. If a number is not in the AuditedBundle,
do not use it.

IMPORTANT: You are not a perma-bear. If a risk is genuinely priced in,
say so. Focus on risks the market is UNDERESTIMATING, not headline fears
everyone already knows.

YOUR DEBATE STRUCTURE:

ROUND 0 — PRE-DEBATE INDEPENDENT OPINION:
State your initial bear conviction score (0–10, where 10 = extremely bearish)
and a 2-sentence rationale.

ROUND 2 — OPENING BEAR CHALLENGE (after Bull's Round 1):
1. CORE BEAR THESIS (3 sentences): The central reason NOT to buy.
2. TOP 5 BEAR ARGUMENTS: Each = specific number + mechanism of harm
3. VALUATION CONCERN: What growth rate is priced in? Is it achievable?
4. DOWNSIDE SCENARIOS:
   - Base case: return if risks materialise
   - Tail risk: what scenario causes >30% decline?
5. COUNTER TO BULL: Address Bull's 2 pre-emptions specifically. Are they
   correct that these risks are priced or temporary? Prove it or dispute it.

ROUND 4 — BEAR REBUTTAL (after Bull's rebuttal):
Address Bull's DEFEND points. For each: accept their data as correct but
challenge their interpretation, OR show that their data is incomplete.
Updated conviction score (max ±1.5 from Round 0 score).

ROUND 7 — CLOSING STATEMENT:
Two paragraphs. First: what risk(s) the bull case is glossing over.
Second: at what price would you become neutral or bullish?

End every round with:
BEAR CONVICTION SCORE: X/10 — "<one sentence justification>"

OUTPUT: Respond in structured text (not JSON). Label each round clearly.
```

---

### PROMPT 10 — CIO (Chief Investment Officer)
**File:** `config/prompts/cio.md`  
**Model:** `deepseek-v4-pro` (default) | **Temperature:** 0.1

```
You are the Chief Investment Officer of a premier Indian hedge fund.
You have just reviewed a complete investment analysis for {ticker} ({company_name}),
including 6 specialist reports, an Evidence Audit, and a full Bull vs Bear debate.

Your role is to make the final investment decision and produce a
professional-grade multidimensional investment memo.

You are NOT trying to average the scores. You are exercising judgment —
weighing arguments by evidence quality, not volume.

INPUTS YOU HAVE:
1. Fundamental Analysis report + score (verified by Evidence Auditor)
2. Macro & News report + score
3. Competitive Moat report + score
4. Risk Officer narrative + Deterministic Risk Score (det_risk_score)
5. Growth & Valuation report + score
6. Market Regime Snapshot + sector_regime_multiplier
7. Evidence Auditor output: reliability_score + confidence_adjustment
8. Full Bull vs Bear debate transcript (8 rounds)
9. Scoring weights from config: {weights}

MANDATORY SCORING FORMULA (execute in this exact order):

Step 1 — Weighted raw:
  raw = (fund_score × {w_fund}) +
        (macro_score × {w_macro}) +
        (moat_score × {w_moat}) +
        (growth_score × {w_growth}) +
        ((10 − det_risk_score) × {w_risk})

Step 2 — Confidence penalty:
  raw = raw + confidence_adjustment    (confidence_adjustment is ≤ 0)

Step 3 — Debate adjustment (optional, requires justification, max ±0.75):
  Apply only if one side had a clearly decisive, data-backed argument
  that changes the weight you assign to a specific dimension.

Step 4 — Regime multiplier:
  final_rating = clamp(raw + sector_regime_multiplier, 0, 10)

UNCERTAINTY FLAGS:
  If max(agent_scores) − min(agent_scores) > 3.0 → HIGH_UNCERTAINTY
    → recommended_position_size reduced by 50% vs normal
  If spread ≤ 2.0 → LOW_UNCERTAINTY

BUSINESS QUALITY vs INVESTMENT QUALITY:
  business_quality = (moat_score × 0.35) + (fund_score × 0.35)
                     + ((10 − det_risk_score) × 0.30)
  investment_quality = (growth_score × 0.40) + (valuation_subcomponent × 0.35)
                       + (macro_score × 0.25)

VERDICT LABELS:
  9.0–10.0: STRONG BUY — HIGH CONVICTION
  7.5–8.9:  BUY — MODERATE CONVICTION
  6.0–7.4:  ACCUMULATE — WATCH CLOSELY
  4.5–5.9:  HOLD — NEUTRAL
  3.0–4.4:  REDUCE — CAUTION
  0.0–2.9:  AVOID — SELL

POSITION SIZE GUIDANCE (adjust for uncertainty):
  STRONG BUY + LOW_UNCERTAINTY:   5–7% of portfolio
  BUY + LOW_UNCERTAINTY:          3–5%
  BUY + HIGH_UNCERTAINTY:         1.5–2.5%
  ACCUMULATE:                     1–2%
  HOLD/REDUCE/AVOID:              0%

Show your work: include the full step-by-step calculation in score_calculation.

STRICT OUTPUT — valid JSON only:
{
  "agent": "cio",
  "ticker": "<ticker>",
  "company_name": "<name>",
  "analysis_date": "<ISO date>",
  "investment_horizon_months": <int>,

  "scores": {
    "business_quality":  <float 0-10>,
    "investment_quality": <float 0-10>,
    "valuation_score":   <float 0-10>,
    "macro_risk":        <float 0-10>,
    "execution_risk":    <float 0-10>,
    "catalyst_score":    <float 0-10>
  },

  "final_rating":   <float 0-10>,
  "verdict":        "<STRONG BUY | BUY | ACCUMULATE | HOLD | REDUCE | AVOID>",
  "conviction":     "<HIGH | MODERATE | LOW>",
  "uncertainty":    "<HIGH | MEDIUM | LOW>",

  "expected_cagr":               "<pct range, e.g. 18-22%>",
  "recommended_position_size":   "<pct range, e.g. 3-5%>",
  "recommended_holding_period":  "<e.g. 2-3 years>",

  "score_calculation": {
    "weighted_raw":        <float>,
    "confidence_penalty":  <float>,
    "debate_adjustment":   <float>,
    "regime_multiplier":   <float>,
    "final":               <float>
  },

  "five_point_summary": [
    "1. <key insight with specific data>",
    "2. <key insight with specific data>",
    "3. <key insight with specific data>",
    "4. <key insight with specific data>",
    "5. <key insight with specific data>"
  ],

  "geopolitical_regime_flags": ["<flag with data>"],
  "recommended_hold_months":   { "min": <int>, "max": <int> },
  "buy_below_price":           "<price or N/A>",
  "next_catalyst_to_watch":    "<specific event or date>",
  "thesis_invalidating_risk":  "<single most dangerous risk>",
  "debate_decisive_argument":  "<which side, which specific point>"
}
```

---

## 11. Shared KnowledgeGraph

One fetch. Every agent reads the same object. No agent calls any data source independently.

```python
# src/data/knowledge_graph.py
from dataclasses import dataclass

@dataclass
class KnowledgeGraph:
    # ── Identity ──────────────────────────────────────────────────
    ticker: str
    exchange: str                    # "IN" | "US"
    company_name: str
    sector: str
    industry: str
    fetch_timestamp: str
    data_gaps: list[str]

    # ── Fundamentals ──────────────────────────────────────────────
    balance_sheet: dict              # 5-year history
    income_statement: dict
    cash_flow: dict
    key_ratios: dict                 # ROE, ROA, D/E, FCF margin, interest coverage
    valuation_metrics: dict          # P/E, P/B, EV/EBITDA, PEG, market cap

    # ── Ownership ─────────────────────────────────────────────────
    promoter_holding: list           # quarterly trend + pledge %
    fii_holding: list
    dii_holding: list
    insider_transactions: list

    # ── News & Sentiment ─────────────────────────────────────────
    news_headlines: list             # last 30 days + sentiment scores
    analyst_ratings: dict
    earnings_surprises: list         # last 4 quarters

    # ── Competitive ───────────────────────────────────────────────
    peers: list                      # peer tickers + key ratios
    market_position: dict

    # ── Governance ────────────────────────────────────────────────
    governance_flags: list
    debt_schedule: dict

    # ── Regime ────────────────────────────────────────────────────
    regime_data: dict                # VIX US, VIX India, crude, DXY, USD/INR
    fii_flow_30d: float
    geopolitical_headlines: list
    macro_indicators: dict           # RBI/Fed signals, CPI, GDP, IIP

    # ── Session ───────────────────────────────────────────────────
    investment_duration_months: int
    analysis_depth: str              # "quick" | "balanced" | "premium"

    def extract(self, fields: list[str]) -> dict:
        """Return only the fields an agent needs — keeps prompts tight."""
        return {f: getattr(self, f) for f in fields if hasattr(self, f)}
```

---

## 12. Market Regime Data Sources and Sector Sensitivity

```python
# src/data/regime_fetcher.py

REGIME_SOURCES = {
    "vix_us":      "Yahoo Finance ^VIX",
    "vix_india":   "Yahoo Finance ^NIFVIX",
    "crude_brent": "Yahoo Finance BZ=F",
    "dxy":         "Yahoo Finance DX-Y.NYB",
    "usdinr":      "Yahoo Finance USDINR=X",
    "nifty_200ma": "Calculated from Yahoo Finance ^NSEI",
    "fii_flows":   "NSE India bulk deals RSS",
    "rbi_signals": "RBI press release RSS",
    "geo_news":    "Google News RSS — geopolitical keywords",
    "us_macro":    "FRED API (free) — Fed Funds Rate, CPI, unemployment",
}

GEOPOLITICAL_KEYWORDS = {
    "oil_supply":      ["OPEC", "crude output", "oil supply cut", "petroleum embargo"],
    "semiconductor":   ["chip shortage", "TSMC", "Taiwan Strait", "export controls chips"],
    "trade_war":       ["tariff", "trade war", "trade restrictions", "import duty"],
    "sanctions":       ["sanctions", "sanctioned", "blocked exports"],
    "currency_stress": ["currency crisis", "dollar index", "DXY spike", "EM selloff"],
    "india_macro":     ["FII outflow India", "RBI rate", "INR depreciation", "India CAD"],
    "commodity_shock": ["metal prices", "steel", "aluminium", "copper spike", "agri prices"],
}

SECTOR_GEOPOLITICAL_SENSITIVITY = {
    "IT_EXPORTS":    {"trade_war": -0.8, "dollar_strength": +0.8, "rate_cut_us": +0.3},
    "OIL_GAS":       {"oil_shock": +1.5, "trade_war": -0.3, "sanctions": -0.5},
    "AVIATION":      {"oil_shock": -1.5, "trade_war": -0.5, "rate_cut": +0.3},
    "PHARMA":        {"trade_war": -0.4, "usfda": -0.8, "dollar_strength": +0.4},
    "BANKS_NBFC":    {"rate_hike": -0.8, "rate_cut": +0.8, "fii_outflow": -0.5, "credit_growth": +0.5},
    "FMCG":          {"oil_shock": -0.3, "rural_income": +0.5, "inflation_high": -0.4},
    "METALS_MINING": {"china_slowdown": -1.0, "infra_push": +1.0, "sanctions_russia": +0.5},
    "REAL_ESTATE":   {"rate_hike": -1.0, "rate_cut": +1.0, "fii_inflow": +0.3},
    "AUTO":          {"ev_disruption": -0.5, "commodity_spike": -0.5, "rate_cut": +0.4},
    "RENEWABLES":    {"policy_push": +1.2, "rate_hike": -0.3, "green_infra": +0.8},
    "TELECOM":       {"arpu_growth": +0.6, "price_war": -0.8, "5g_rollout": +0.5},
    "DIVERSIFIED":   {"oil_shock": -0.2, "rate_cut": +0.4, "fii_inflow": +0.4},
}
```

---

## 13. Error Handling and Robustness

### Agent failure recovery

```python
async def run_with_fallback(agent_fn, agent_name, kg, llm_factory, config):
    try:
        return await agent_fn(kg, llm_factory.get_llm_with_fallback(agent_name, config))
    except Exception as e:
        logger.error(f"Agent {agent_name} failed: {e}")
        return {"agent": agent_name, "error": str(e), "score": None}

# Orchestrator handles partial failures
def handle_missing_agent(agent_name, results, weights):
    if results.get(agent_name, {}).get("score") is None:
        missing_weight = weights.pop(agent_name, 0)
        weights["fundamental"] = weights.get("fundamental", 0) + missing_weight
        return f"NOTE: {agent_name} unavailable — weight redistributed to fundamental."
    return ""
```

### Hallucination guard (reinforced by Evidence Auditor)

Every agent prompt contains: *"Do NOT cite any metric not present in the data provided. Write null for missing values. Do not estimate or interpolate."*

The Evidence Auditor then independently cross-checks every cited number. Discrepancies are corrected in the AuditedBundle before the debate begins. The CIO receives only audited data.

### Model unavailability cascade

```
1. Attempt primary model via Ollama (health_check ping)
2. If unavailable: switch to fallback model from settings.yaml
3. If fallback also unavailable: try direct API client (Gemini/OpenAI/Claude)
4. If all fail: skip agent, redistribute weight, flag in report
```

---

## 14. Final Report Format

```
╔═══════════════════════════════════════════════════════════════════════════╗
║              HFIP v2.2 FINAL REPORT — RELIANCE.NS (India)                ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  FINAL RATING: 8.2/10   [BUY — MODERATE CONVICTION]                      ║
║  Investment Horizon: 18 months  |  Uncertainty: LOW                      ║
║  Evidence Reliability: 8.4/10   (confidence penalty: −0.1 applied)       ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  MULTIDIMENSIONAL SCORES:                                                 ║
║    Business Quality:    9.1/10  (moat + fundamental + governance)         ║
║    Investment Quality:  7.8/10  (growth + valuation + macro)              ║
║    Valuation:           7.0/10  (fair vs peers; 22x P/E = hist midpoint)  ║
║    Macro Risk:          4.2/10  (low; regime mild risk-on)                ║
║    Execution Risk:      3.5/10  (low; debt elevated but manageable)       ║
║    Catalyst Score:      8.0/10  (Jio Financial, Retail Tier-2 expansion)  ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  AGENT SCORES (post-audit):                                               ║
║    Fundamental   [deepseek-v4-pro]:   7.5  (wt 25%)                      ║
║    Macro & News  [glm-5.2]:           6.5  (wt 20%)                      ║
║    Moat          [gemini-flash]:      8.0  (wt 15%)                      ║
║    Risk inverted [det. engine]:       6.0  (wt 20%)  ← severity was 4.0  ║
║    Growth/Val    [gemini-flash]:      7.0  (wt 20%)                      ║
║    Weighted Raw: 7.1                                                      ║
║    Confidence penalty: −0.1   Debate adj: +0.2   Regime: +0.2            ║
║    FINAL: 8.2/10                                                          ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  BULL vs BEAR  [kimi-k2.5]:                                               ║
║    Bull final: 8.0/10 — "Jio + retail TAM expansion not priced at 22x"  ║
║    Bear final: 5.5/10 — "Debt/EBITDA 3.8x caps re-rating potential"     ║
║    Committee decisive question: "What event invalidates bull thesis?"    ║
║    → Both sides agreed: sustained crude >$110/bbl (Jamnagar margin hit)  ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  5-POINT SUMMARY:                                                         ║
║    1. Jio: 480M subs, ARPU ₹181 and rising — secular compounder          ║
║    2. Retail: profitable since Q2 FY25; Tier 2/3 runway = 3–4x current  ║
║    3. Debt/EBITDA 3.8x elevated but FCF improving QoQ — manageable       ║
║    4. 22x P/E is fair vs 18–24x historical band; not stretched           ║
║    5. New Energy (green H2, solar) — 5yr optionality, not yet priced     ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  GEOPOLITICAL/REGIME FLAGS  [minimax-m2.1]:                               ║
║    - Oil: Brent $87/bbl, within comfort range for Jamnagar refinery      ║
║    - FII: net buyer ₹2,400cr in last 30 days (positive signal)           ║
║    - RBI: rate cut bias developing — positive for Jio Financial NBFC     ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  RECOMMENDED HOLD: 18–36 months                                           ║
║  EXPECTED CAGR: 18–22%   POSITION SIZE: 3–5%                             ║
║  BUY BELOW: ₹1,280  |  NEXT CATALYST: Q1 FY27 results (Retail margin)   ║
║  THESIS RISK: Crude >$110/bbl sustained — Jamnagar margin compression    ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 15. Implementation Roadmap

| Phase | Work | Key Models Needed |
|-------|------|------------------|
| **1** | KnowledgeGraph + unified fetch + OllamaClient + settings.yaml | Any (test with gemini-flash) |
| **2** | Deterministic Risk Engine (Python only — no LLM) | None |
| **3** | Fundamental + Risk Narrative agents | deepseek-v4-pro, glm-5.2 |
| **4** | Macro + Moat + Growth agents | glm-5.2, gemini-flash |
| **5** | Market Regime Agent + regime_fetcher.py | minimax-m2.1 |
| **6** | Evidence Auditor + AuditedBundle | gpt-oss-120b |
| **7** | Bull/Bear debate — 8 rounds + committee Q&A | kimi-k2.5 |
| **8** | CIO with multidimensional output schema | deepseek-v4-pro |
| **9** | Async parallel runner + 3-level cache | — |
| **10** | Regression test on 10 known stocks (RELIANCE, TCS, HDFC, AAPL, MSFT) | all |
| **11** | Streamlit dashboard update (show multidimensional scores + debate) | — |

---

## 16. What Was Accepted / Rejected from v2.1 PDF Enhancements

| PDF Suggestion | Decision | Rationale |
|---------------|----------|-----------|
| Evidence Auditor agent | ✅ Adopted fully | Genuinely fills the gap between agent output and debate; much stronger than the post-hoc metric check in v2.1 |
| Config-driven model routing | ✅ Adopted + extended | PDF had the right idea; v2.2 extends it with execution modes (quick/balanced/premium) and full LLM fallback cascade |
| Enhanced debate (8 rounds + committee Q&A) | ✅ Adopted with compression | Kept 8-round structure but committee Q&A uses 5 hard-coded questions (not LLM-generated) to control token use |
| CIO multidimensional output | ✅ Adopted fully | `business_quality` vs `investment_quality` separation, expected CAGR, and position size are genuine improvements |
| Deterministic Risk Engine | ✅ Adopted fully | Separating rule-based computation from LLM narrative is the right architectural call — consistent, testable, reproducible |
| PDF's Bear model = deepseek-v4-pro | ❌ Rejected | Both Bull and Bear use kimi-k2.5 for symmetry. If Bull uses a different (weaker) model, the outcome is biased toward the Bear before the debate starts. |
| PDF's CIO model = gpt-oss-120b | ❌ Rejected | CIO is the hardest synthesis job in the pipeline — 10 inputs, formula application, and genuine judgment. deepseek-v4-pro (9.8 reasoning) is the correct choice over gpt-oss-120b (9.4). |

---

*This document is the authoritative architecture reference for HFIP v2.2. All implementation must align with the settings.yaml defaults in Section 5 and the agent prompts in Section 10. Model assignments are defaults — change them only in settings.yaml.*
